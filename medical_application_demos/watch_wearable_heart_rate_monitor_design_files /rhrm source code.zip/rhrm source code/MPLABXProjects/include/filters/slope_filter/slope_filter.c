/*******************************************************************************
 * Slope (Differential) Filter
 * 
 * Company:
 *  Microchip Technology Inc.
 * 
 * File Name:
 *  slope_filter.c
 * 
 * Summary:
 *  Slope filter provides a smoothed approximation of the derivative.
 * 
 * Description:
 *  Slope filter is a FIR composed of two moving averages, one subtracted from
 *  the other.  User specifies the size of the moving averages to smooth the
 *  result.  Result is a smoother approximation to the derivative of the input
 *  signal.
 * 
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

//
// Section: Included Files
//

#include "slope_filter.h"

#include <stdbool.h>
#include <stdint.h>

#include "debug_print/debug_print.h"
#include "embed_assert/embed_assert.h"
#include "filters/moving_filter/moving_filter.h"

//
// Section: Slope filter APIs
//

void SLOPE_FilterDelete(SLOPE_FILTER_T *filter)
{
    MA_FilterDelete(filter->negative);
    MA_FilterDelete(filter->positive);
    free(filter);
}

SLOPE_FILTER_T *SLOPE_FilterNew(SLOPE_SIZE_T _size)
{
    SLOPE_FILTER_T *filter = malloc(sizeof (SLOPE_FILTER_T));
    filter->positive = MA_FilterNew(_size);
    filter->negative = MA_FilterNew(_size);
    filter->center = 0;
    return filter;
}

void SLOPE_FilterZero(SLOPE_FILTER_T *filter)
{
    MA_FilterZero(filter->positive);
    MA_FilterZero(filter->negative);
    filter->center = 0;
}

SLOPE_REG_T SLOPE_DataShift(SLOPE_FILTER_T *filter, SLOPE_REG_T dataIn)
{
    SLOPE_REG_T dataOut = MA_AverageShift(filter->negative, filter->center);
    filter->center = MA_AverageShift(filter->positive, dataIn);
    return dataOut;
}

SLOPE_REG_T SLOPE_SlopeGet(SLOPE_FILTER_T *filter)
{
    SLOPE_REG_T slope = MA_AverageGet(filter->positive);
    slope -= MA_AverageGet(filter->negative);
    DBP_DebugPrintInt("Slope", slope, 1);
    DBP_DebugPrintInt("Center", filter->center, 1);
    return slope;
}

//
// End of File
//
