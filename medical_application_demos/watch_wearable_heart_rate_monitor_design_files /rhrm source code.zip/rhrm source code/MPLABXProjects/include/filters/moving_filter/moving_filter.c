

/**
  Section: Included Files
 */
#include "moving_filter.h"
#include <stdlib.h>

/**
 * Section: Private Function Prototypes
 */

void MA_ShiftPositionRight(MA_FILTER_T *filter);

/**
 * Section: Private Function Definitions
 */

void MA_FilterZero(MA_FILTER_T *filter) {
    for (int i = 0; i < filter->size; i++) {
        filter->reg[i] = 0;
    }
    filter->sum = 0;
}

void MA_ShiftPositionRight(MA_FILTER_T *filter) {
    filter->position++;
    filter->position %= filter->size;
}

/**
  Section: Moving Average APIs
 */

void MA_FilterDelete(MA_FILTER_T *filter) {
    free(filter->reg);
    free(filter);
}

MA_FILTER_T *MA_FilterNew(MA_SIZE_T _size) {
    MA_FILTER_T *filter = malloc(sizeof (MA_FILTER_T));
    filter->reg = malloc(sizeof (MA_REG_T) * _size);
    filter->size = _size;
    MA_FilterZero(filter);
    filter->position = 0;
    return filter;
}

MA_REG_T MA_AverageShift(MA_FILTER_T *filter, MA_REG_T dataIn) {
    MA_REG_T dataOut = filter->reg[filter->position];
    filter->sum -= dataOut;
    filter->sum += dataIn;
    filter->reg[filter->position] = dataIn;
    MA_ShiftPositionRight(filter);
    return dataOut;
}

MA_REG_T MA_AverageGet(MA_FILTER_T *filter) {
    return (filter->sum / (MA_SUM_T) filter->size);
}
