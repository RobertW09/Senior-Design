/*
 * File:   moving_filter.h
 * Author: C15140
 *
 * Created on October 16, 2015, 5:04 PM
 */

#ifndef MOVING_FILTER_H
#define MOVING_FILTER_H

/**
  Section: Included Files
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

/**
  Section: Data Types
 */

// Datatype for describing size and position inside of the FIFO (.reg)
typedef size_t MA_SIZE_T;

#ifndef int24_t
typedef int32_t int24_t;
#endif

typedef int24_t MA_REG_T;

typedef int32_t MA_SUM_T;

/**
 * Filter Structure
 *
 * Contains parameters for storing and processing filter data.
 */
typedef struct
{
    // FIFO shift register for moving data in and out of averaging window.
    MA_REG_T *reg;

    // Number of data points in the shift register
    MA_SIZE_T size;

    // Position data was last stored into the FIFO (.reg)
    MA_SIZE_T position;

    // Sum of all values in reg
    MA_SUM_T sum;

} MA_FILTER_T;


/**
  Section: Moving Average APIs
 */

void MA_FilterDelete(MA_FILTER_T *filter);

/**
 *
 * @Summary
 *  Creates new moving average filter
 *
 * @Description
 *  Allocates memory for a new moving average filter of the specified size, and
 *  returns a pointer to the structure.
 *
 * @Preconditions
 *  Must have malloc implemented, and enough memory allocated
 *
 * @Params
 *  _size - The number of samples stored in the moving average
 *
 * @Returns
 *  Pointer to the new MA_FILTER_T
 *
 * @Example
 *   <code>
 *   MA_FILTER_T *myFilter = MA_FilterNew(4);  // create moving average over 4 samples
 *   </code>
 *
 * @Comment
 *  There's no delete function (MA_FilterDelete), since the filter is created at
 *  starup and never deleted for the life of the application.
 *
 * @See Also
 *  MA_AverageShift()
 *  MA_AverageGet()
 *  
 */
MA_FILTER_T *MA_FilterNew(MA_SIZE_T _size);

/**
 * Zeros out the filter.
 * Writes 0s to all array positions and sets the sum equal to 0.
 * @param filter
 */
void MA_FilterZero(MA_FILTER_T *filter);

/**
 *
 * @Summary
 *  Averages new data.
 *
 * @Description
 *  Shifts new data into the moving average and returns the new average.
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  *filter - pointer to the filter structure
 *  dataIn - new input data
 *
 * @Returns
 *  Average of the data in the filter's FIFO
 *
 * @Example
 *   <code>
 *   MA_FILTER_T *dataFilter = MA_FilterNew(4);
 *   while(1)
 *   {
 *      int16_t newData = ADC_result();
 *      int16_t filteredData = MA_AverageShift(dataFilter, newData);
 *      printf("%ld\r\n", (long) filteredData);
 *   } 
 *   </code>
 *
 * @See Also
 *  MA_FilterNew();
 *  MA_AverageGet();
 *  
 */
MA_REG_T MA_AverageShift(MA_FILTER_T *filter, MA_REG_T dataIn);

/**
 *
 * @Summary
 *  Gets the averaged data.
 *
 * @Description
 *  Gets the averaged data from the filter.  Makes no changes to the filter.
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  *filter - pointer to the filter structure
 *
 * @Returns
 *  Average of the data in the filter's FIFO
 *
 * @Example
 *   <code>
 *   MA_FILTER_T *dataFilter = MA_FilterNew(4);
 *   while(1)
 *   {
 *      int16_t newData = ADC_result();
 *      (void) MA_AverageShift(dataFilter, newData); // Discard the returned value
 *      int16_t filteredData = MA_AverageGet(dataFilter);
 *      printf("%ld\r\n", (long) filteredData);
 *   } 
 *   </code>
 *
 * @See Also
 *  MA_FilterNew();
 *  MA_AverageShift();
 *  
 */
MA_REG_T MA_AverageGet(MA_FILTER_T *filter);

#endif /* MOVING_FILTER_H */

