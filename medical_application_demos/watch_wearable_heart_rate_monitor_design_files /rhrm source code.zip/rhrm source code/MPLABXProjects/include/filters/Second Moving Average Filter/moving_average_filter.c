/*
 * File:   moving_average_filter.h
 * Author: C12903 Zhang Feng
 *
 * Created on 2/6/2017
 */

#include "moving_average_filter.h"
#include <stdlib.h>


// Initialize second moving_average_filter
void MA2_Filter_init(MA2_Filter_t *filter, int size)
{
    filter->size = size;
    filter->start = 0;
    filter->count = 0;
//    filter->element = malloc(sizeof(filter->element)*size);
    filter->element = malloc(sizeof (int24_t) * size);
}

// Second moving_average_filter
int24_t MA2_Filter(MA2_Filter_t *filter, int24_t *dataIn)
{
    int i;
    int24_t sum;
    int24_t dataOut;
    
    if (filter->count == filter->size)
    {
        // Slide moving window down
        for (i = 0; i < (filter->size - 1); i++)
        {
            filter->element[i] = filter->element[i+1];      // element[0]=element[1].....element[8]=element[9]
        }
        filter->element[filter->size-1] = dataIn;       // element[9]=dataIN
        
        // Average
        for (i = 0; i < filter->size; i++)
        {
            sum = sum + filter->element[i];
        }
        ma_filtered = sum / filter->size;
        
        // Remove DC offset
        dc_filtered = (dc_filtered_previous + ma_filtered - ma_filtered_previous) * 0.98;
        dc_filtered_previous = dc_filtered;
        ma_filtered_previous = ma_filtered;
        
        dataOut = dc_filtered;
        return dataOut;
    }
    else
    {
        // Loading FIFO_buffer
        filter->element[filter->count] = dataIn;
        filter->count++;
        return 0;
    }
}


/*******************************************************************************
 * Function Name: int24_t Find_MaxMin(int24_t data)
 * Specification: Detect the max & min value of the input pulsation signal.
 *******************************************************************************/
/*
int24_t Find_MaxMin(int24_t data)
{
    bool max_found = 0;
    bool min_found = 0;
    
	switch (Find_MaxMin_State)
	{
		case 0:
			data_max = data;
			Find_MaxMin_State = 1;
			break;

		case 1:
			if (data >= data_max)
			{
				data_max = data;
				Find_MaxMin_State = 2;
			}
			else
			{
				Find_MaxMin_State = 0;
			}
			break;

		case 2:		//Finding Max
			if (data >= data_max)
			{
				data_max = data;
				Sample_Window_Counter = Sample_Window_Interval_down;		//restart counter
			}
			else
			{
				Sample_Window_Counter--;			//signal is now going down
				if (Sample_Window_Counter == 0)		//no more max peaks detected in the sampling window interval, go to detect min
				{
                    if (data_max > max_thershold)
                    {
                        max_found = 1;
                        pulse_max_value = data_max;
                        data_min = data;
                        Find_MaxMin_State = 3;          //go to next state - Finding Min state
                    }
				}
			}
			break;
            
        case 3:		//Finding Min
			if (data <= data_min)
			{
				data_min = data;
				Sample_Window_Counter = Sample_Window_Interval_up;		//restart counter
			}
			else
			{
				Sample_Window_Counter--;			//signal is now going up
				if (Sample_Window_Counter == 0)		//no more min peaks detected in the sampling window interval, go to detect max
				{
                    min_found = 1;
                    pulse_min_value = data_min;
					data_max = data;
                    Pulse_Detection_Done = 1;		//Found Max & Min
					Find_MaxMin_State = 1;			//go to next state
				}
			}
			break;
            
        default:
            break;
	}
    
    if (max_found == 1) {
        return data_max;
    } else {
        return 0;
    }
}
*/

// Second DC removal filter
int24_t DC_Filter(int24_t data)
{
    dc_filtered = (dc_filtered_previous + data - data_previous) * 0.98;
    dc_filtered_previous = dc_filtered;
    data_previous = data;
    return dc_filtered;
}
