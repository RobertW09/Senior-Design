/*
 * File:   moving_filter.h
 * Author: C15140
 *
 * Created on October 16, 2015, 5:04 PM
 */

#ifndef MOVING_AVERAGE_FILTER_H
#define MOVING_AVERAGE_FILTER_H

/**
  Section: Included Files
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>


struct moving_average_filter {
    int size;
    int start;
    //int end;  // position of last element
    /* Tracking start and end of buffer would waste
     * one position. A full buffer would always have
     * to leave last position empty or otherwise
     * it would look empty. Instead this buffer uses
     * count to track if buffer is empty or full
     */
    int count; // number of elements in buffer
    /* Two ways to make buffer element type opaque
     * First is by using typedef for the element
     * pointer. Second is by using void pointer.
     */
    /* different types of buffer: 
    int *element;   // array of integers
    char *element;  // array of characters 
    void *element;  // array of void type (could cast to int, char, etc)
    char **element; //array of char pointers (array of strings)
    void **element; // array of void pointers
    Choosing array of void pointers since it's the most flexible */
    int24_t *element;
};

typedef struct moving_average_filter MA2_Filter_t;

int24_t ma_filtered_previous = 0;
int24_t dc_filtered_previous = 0;
int24_t ma_filtered = 0;
int24_t dc_filtered = 0;
int24_t data_previous = 0;

//int8_t Find_MaxMin_State = 0;
//int24_t data_max, data_min;
//int16_t Sample_Window_Counter;
//int8_t Pulse_Detection_Done;
//int24_t pulse_max_value, pulse_min_value;

//#define Sample_Window_Interval_down		27
//#define Sample_Window_Interval_up		16
//#define max_thershold   50

void MA2_Filter_init(MA2_Filter_t *filter, int size);

int24_t MA2_Filter(MA2_Filter_t *filter, int24_t *dataIn);

//int24_t Find_MaxMin(int24_t data);

int24_t DC_Filter(int24_t data);


#endif /* MOVING_AVERAGE_FILTER_H */
