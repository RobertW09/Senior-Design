/*
 * File:   moving_filter.h
 * Author: C15140
 *
 * Created on October 16, 2015, 5:04 PM
 */

#ifndef PULSE_FILTER_H
#define	PULSE_FILTER_H

/**
  Section: Included Files
 */

#include <stdbool.h>
#include <stdint.h>
#include "types/rpo_types.h"
#include "filters/moving_filter/moving_filter.h"

/**
  Section: Data Types
 */

/**
 * Filter Structure
 *
 * Contains parameters for storing and processing filter data.
 */
typedef struct
{
    // First pass of moving filter
    MA_FILTER_T *firstPass;
    // Second pass of moving filter
    MA_FILTER_T *secondPass;
    // Data used for high pass filter
    RPO_LONG_INT_T highPass;
    // current minimum
} PULSE_FILTER_T;

/**
  Section: Moving Average APIs
 */

void PF_FilterDelete(PULSE_FILTER_T *filter);

/**
 *
 * @param filter
 * @param _size
 */
PULSE_FILTER_T *PF_FilterNew(uint8_t lowPass1, uint8_t lowPass2);

/**
 *
 * @param filter
 * @param dataIn
 */
RPO_CORRELATED_INT_T PF_SampleShift(PULSE_FILTER_T *filter, RPO_CORRELATED_INT_T dataIn);

RPO_CORRELATED_INT_T PF_DataPeakToPeakGet(PULSE_FILTER_T *filter);

void PF_DataMinMaxReset(PULSE_FILTER_T *filter);

#endif	/* PULSE_FILTER_H */

