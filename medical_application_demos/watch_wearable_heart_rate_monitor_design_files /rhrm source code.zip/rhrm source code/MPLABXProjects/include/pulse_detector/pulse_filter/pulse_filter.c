
/**
  Section: Included Files
 */

#include "pulse_filter.h"

#include <stdlib.h>

#include "debug_print/debug_print.h"
#include "embed_assert/embed_assert.h"

/**
  Section: Constants
 */
#ifdef __XC
#define PF_HP_FILTER_CONST (16)
#else
uint8_t PF_HP_FILTER_CONST = 16;
#endif

/**
  Section: Global Variables Definitions
 */

/**
  Section: Helper Prototypes
 */

/**
  Section: Helper Functions
 */

/**
  Section: Coorelated Sample Module APIs
 */

void PF_FilterDelete(PULSE_FILTER_T *filter)
{
    MA_FilterDelete(filter->secondPass);
    MA_FilterDelete(filter->firstPass);
    free(filter);
}

PULSE_FILTER_T *PF_FilterNew(uint8_t lowPass1, uint8_t lowPass2)
{
    PULSE_FILTER_T *filter = malloc(sizeof (PULSE_FILTER_T));
    filter->firstPass = MA_FilterNew((MA_SIZE_T) lowPass1);
    filter->secondPass = MA_FilterNew((MA_SIZE_T) lowPass2);
    filter->highPass = 0;

    return filter;
}

RPO_CORRELATED_INT_T PF_SampleGet(PULSE_FILTER_T *filter)
{
    RPO_CORRELATED_INT_T sample = MA_AverageGet(filter->secondPass);
    sample -= filter->highPass;
    return sample;
}

RPO_CORRELATED_INT_T PF_SampleShift(PULSE_FILTER_T *filter, RPO_CORRELATED_INT_T dataIn)
{
    (void) MA_AverageShift(filter->firstPass, dataIn);
    RPO_CORRELATED_INT_T dataLowPass1 = MA_AverageGet(filter->firstPass);
    DBP_DebugPrintInt("LowPass1", dataLowPass1, 2);

    (void) MA_AverageShift(filter->secondPass, dataLowPass1);
    RPO_CORRELATED_INT_T dataLowPass2 = MA_AverageGet(filter->secondPass);
    DBP_DebugPrintInt("LowPass2", dataLowPass2, 2);

    filter->highPass *= (PF_HP_FILTER_CONST - 1);
    filter->highPass += dataLowPass2;
    filter->highPass /= PF_HP_FILTER_CONST;

    RPO_CORRELATED_INT_T dataFiltered = dataLowPass2 - filter->highPass;

    return dataFiltered;
}


