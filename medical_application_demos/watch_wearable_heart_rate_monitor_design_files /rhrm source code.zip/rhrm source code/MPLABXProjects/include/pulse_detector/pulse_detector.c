
/**
  Section: Included Files
 */

#include "pulse_detector.h"
#include "embed_assert/embed_assert.h"
#include "debug_print/debug_print.h"
#include <stdlib.h>

/**
  Section: Constants
 */

//#define PD_THRESHOLD_UPPER_DEFAULT (100)
//#define PD_THRESHOLD_LOWER_DEFAULT (-50)
#define PD_THRESHOLD_UPPER_DEFAULT (2000)
#define PD_THRESHOLD_LOWER_DEFAULT (-1000)

/**
 * Section: Macros
 */
#define PD_Min(a, b) (a > b ? b : a)
#define PD_Max(a, b) (a < b ? b : a)

/**
 * Section: Pulse Detector Private Functions
 */

/**
 * Section: Private Function Prototypes
 */
static RPO_CORRELATED_INT_T PD_SlopeCurrentGet(PD_DETECTOR_T *detector,
                                               RPO_CORRELATED_INT_T dataCurrent);
static PD_DETECTION_STATE_T PD_StateInitial(RPO_CORRELATED_INT_T thresholdLower,
                                            RPO_CORRELATED_INT_T slope);
static PD_DETECTION_STATE_T PD_StateFalling(RPO_CORRELATED_INT_T slopePrevious,
                                            RPO_CORRELATED_INT_T slopCurrent);
static PD_DETECTION_STATE_T PD_StateTrough(RPO_CORRELATED_INT_T thresholdLower,
                                           RPO_CORRELATED_INT_T thresholdUpper,
                                           RPO_CORRELATED_INT_T slope);
static PD_DETECTION_STATE_T PD_StateRising(RPO_CORRELATED_INT_T slopePrevious,
                                           RPO_CORRELATED_INT_T slopCurrent);

/**
 * Section: Private Function Definitions
 */

static RPO_CORRELATED_INT_T PD_SlopeCurrentGet(PD_DETECTOR_T *detector,
                                               RPO_CORRELATED_INT_T dataCurrent)
{
    (void) SLOPE_DataShift(detector->slopeFilter, dataCurrent);
    RPO_CORRELATED_INT_T slopeCurrent = SLOPE_SlopeGet(detector->slopeFilter);
    return (slopeCurrent);
}

static PD_DETECTION_STATE_T PD_StateInitial(RPO_CORRELATED_INT_T thresholdLower,
                                            RPO_CORRELATED_INT_T slope)
{
    PD_DETECTION_STATE_T newState = PD_INITIAL;
    if (thresholdLower > slope)
    {
        newState = PD_FALLING;
    }
    return newState;
}

static PD_DETECTION_STATE_T PD_StateFalling(RPO_CORRELATED_INT_T slopePrevious,
                                            RPO_CORRELATED_INT_T slopeCurrent)
{
    PD_DETECTION_STATE_T newState = PD_FALLING;
    if ((0 > slopePrevious) && (0 <= slopeCurrent)) // Trough value?
    {
        newState = PD_TROUGH;
    }
    return newState;
}

static PD_DETECTION_STATE_T PD_StateTrough(RPO_CORRELATED_INT_T thresholdLower,
                                           RPO_CORRELATED_INT_T thresholdUpper,
                                           RPO_CORRELATED_INT_T slope)
{
    PD_DETECTION_STATE_T newState = PD_TROUGH;
    if (thresholdUpper < slope) // Steep up slope?
    {
        newState = PD_RISING;
    }
    else if (thresholdLower > slope)
    {
        newState = PD_FALLING;
    }
    return newState;
}

static PD_DETECTION_STATE_T PD_StateRising(RPO_CORRELATED_INT_T slopePrevious,
                                           RPO_CORRELATED_INT_T slopeCurrent)
{
    PD_DETECTION_STATE_T newState = PD_RISING;
    if ((0 < slopePrevious) && (0 >= slopeCurrent)) // Peak value?
    {
        newState = PD_PULSE_DETECTED;
    }
    return newState;
}

/**
  Section: Pulse Detector APIs
 */

void PD_DetectorDelete(PD_DETECTOR_T *detector)
{
    SLOPE_FilterDelete(detector->slopeFilter);
    free(detector);
}

PD_DETECTOR_T *PD_DetectorNew(size_t slopeSize)
{
    PD_DETECTOR_T *detector = malloc(sizeof (PD_DETECTOR_T));
    detector->slopeFilter = SLOPE_FilterNew(slopeSize);
    detector->detectionState = PD_INITIAL;
    detector->slope = 0;
    detector->min = 0;
    detector->max = 0;
    detector->pkToPk = 0;
    detector->thresholdLower = PD_THRESHOLD_LOWER_DEFAULT;
    detector->thresholdUpper = PD_THRESHOLD_UPPER_DEFAULT;
    return (detector);
}

void PD_ThresholdLowerSet(PD_DETECTOR_T *detector,
                          RPO_CORRELATED_INT_T _thresholdLower)
{
    detector->thresholdLower = _thresholdLower;
}

void PD_ThresholdUpperSet(PD_DETECTOR_T *detector,
                          RPO_CORRELATED_INT_T _thresholdUpper)
{
    detector->thresholdUpper = _thresholdUpper;
}

PD_DETECTION_STATE_T PD_PulseDetector(PD_DETECTOR_T *detector,
                                      RPO_CORRELATED_INT_T dataCurrent)
{
    PD_DETECTION_STATE_T newState = PD_INITIAL;
    RPO_CORRELATED_INT_T slopeCurrent = \
            PD_SlopeCurrentGet(detector, dataCurrent);

    switch (detector->detectionState)
    {
    case PD_INITIAL:
        detector->min = detector->slopeFilter->center;
        newState = PD_StateInitial(detector->thresholdLower, slopeCurrent);
        break;
    case PD_FALLING:
        detector->min = PD_Min(detector->min, detector->slopeFilter->center);
        newState = PD_StateFalling(detector->slope, slopeCurrent);
        break;
    case PD_TROUGH:
        detector->min = PD_Min(detector->min, detector->slopeFilter->center);
        detector->max = detector->slopeFilter->center;
        newState = PD_StateTrough(detector->thresholdLower,
                                  detector->thresholdUpper, slopeCurrent);
        break;
    case PD_RISING:
        detector->max = PD_Max(detector->max, detector->slopeFilter->center);
        newState = PD_StateRising(detector->slope, slopeCurrent);
        break;
    case PD_PULSE_DETECTED:
        detector->max = PD_Max(detector->max, detector->slopeFilter->center);
        detector->pkToPk = detector->max - detector->min;
        detector->min = detector->slopeFilter->center;
        newState = PD_StateInitial(detector->thresholdLower, slopeCurrent);
        break;
    default:
        E_ASSERT(false); // Code execution shouldn't reach here.
        break;
    }
    detector->slope = slopeCurrent;
    detector->detectionState = newState;
    DBP_DebugPrintInt("Min", detector->min, 1);
    DBP_DebugPrintInt("Max", detector->max, 1);
    DBP_DebugPrintInt("Peak-Peak", detector->pkToPk, 1);
    return (newState);
}
