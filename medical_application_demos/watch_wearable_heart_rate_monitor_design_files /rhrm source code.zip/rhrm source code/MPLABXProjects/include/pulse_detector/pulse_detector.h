/*
 * File:   pulse_detector.h
 * Author: C15140
 *
 * Created on October 16, 2015, 1:37 PM
 */

#ifndef PULSE_DETECTOR_H
#define PULSE_DETECTOR_H

/**
  Section: Included Files
 */

#include <stdbool.h>
#include <stdint.h>
#include "filters/slope_filter/slope_filter.h"
#include "types/rpo_types.h"

/**
  Section: Data Types
 */

/* Pulse detection state
 *
 * These are the phases of pulse detection
 */

typedef enum {
    // Initial phase.  Looking for a rising slope
    PD_INITIAL,
    // In rising slope, looking for the peak
    PD_FALLING,
    // Peak detected, looking for falling slope
    PD_TROUGH,
    // Falling slope detected, looking for trough
    PD_RISING,
    // Trough detected, full pulse detected, go back to reset
    PD_PULSE_DETECTED
} PD_DETECTION_STATE_T;

/* Pulse Detector Structure
 *
 * Contains the the previously calculated parameters to carry over to the next
 * state calculation.
 */
typedef struct {
    // Current detection state
    PD_DETECTION_STATE_T detectionState;
    // Slope Filter
    SLOPE_FILTER_T *slopeFilter;
    // Previous slope value
    RPO_CORRELATED_INT_T slope;
    RPO_CORRELATED_INT_T min;
    RPO_CORRELATED_INT_T max;
    RPO_CORRELATED_INT_T pkToPk;
    RPO_CORRELATED_INT_T thresholdUpper;
    RPO_CORRELATED_INT_T thresholdLower;
    
} PD_DETECTOR_T;

/**
  Section: Pulse Detector APIs
 */

void PD_DetectorDelete(PD_DETECTOR_T *detector);

/**
 *
 * @return
 */
PD_DETECTOR_T *PD_DetectorNew(size_t slopeSize);

/**
 *
 * @param input
 * @return
 */
void PD_ThresholdLowerSet(PD_DETECTOR_T *detector,
                          RPO_CORRELATED_INT_T _thresholdLower);

/**
 *
 * @param input
 * @return
 */
void PD_ThresholdUpperSet(PD_DETECTOR_T *detector,
                          RPO_CORRELATED_INT_T _thresholdUpper);

/**
 *
 * @param detector
 * @param input
 * @return
 */
PD_DETECTION_STATE_T PD_PulseDetector(PD_DETECTOR_T *detector,
        RPO_CORRELATED_INT_T input);

#endif /* PULSE_DETECTOR_H */

