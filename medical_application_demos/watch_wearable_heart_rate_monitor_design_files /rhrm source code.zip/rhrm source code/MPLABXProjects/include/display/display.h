/*
 * File:   OLED.h
 * Author: C15502
 *
 * Created on September 19, 2014, 3:54 PM
 */
#ifndef _SSD1306_H
#define _SSD1306_H

#include <stdbool.h>
/* ------------------------------------------------------------ */
/*					Miscellaneous Declarations					*/
/* ------------------------------------------------------------ */
//#define _XTAL_FREQ 48000000
#define	cbOledDispMax	96		//max number of bytes in display buffer

typedef enum
{
    Normal, Inverse
} oLED_DisplayMode_t;

#define DOT  0x0E

void oled_writeCommand(uint8_t);
#define DISPLAY_ON()           oled_writeCommand(0xaf)   //  Display on
#define DISPLAY_OFF()          oled_writeCommand(0xae)   //  Display off
#define SET_ADC()              oled_writeCommand(0xa1)   //  Reverse disrect (SEG128-SEG0)
#define CLEAR_ADC()            oled_writeCommand(0xa0)   //  Normal disrect (SEG0-SEG128)
#define REVERSE_DISPLAY_ON()   oled_writeCommand(0xa7)   //  Reverse display : 0 illuminated
#define REVERSE_DISPLAY_OFF()  oled_writeCommand(0xa6)   //  Normal display : 1 illuminated
#define ENTIRE_DISPLAY_ON()    oled_writeCommand(0xa5)   //  Entire dislay   Force whole LCD point
#define ENTIRE_DISPLAY_OFF()   oled_writeCommand(0xa4)   //  Normal display
#define SET_BIAS()             oled_writeCommand(0xa3)   //  bias 1   1/7 bias
#define CLEAR_BIAS()           oled_writeCommand(0xa2)   //  bias 0   1/9 bias
#define SET_MODIFY_READ()      oled_writeCommand(0xe0)   //  Stop automatic increment of the column address by the read instruction
#define RESET_MODIFY_READ()    oled_writeCommand(0xee)   //  Cancel Modify_read, column address return to its initial value just before the Set Modify Read instruction is started
#define LCD_RESET()            oled_writeCommand(0xe2)
#define SET_SHL()              oled_writeCommand(0xc8)   // SHL 1,COM33-COM0
#define CLEAR_SHL()            oled_writeCommand(0xc0)   // SHL 0,COM0-COM33

/* Graphics drawing modes.
 */
#define	modOledSet		0
#define	modOledOr		1
#define	modOledAnd		2
#define	modOledXor		3

/* ------------------------------------------------------------ */
/*					General Type Declarations					*/
/* ------------------------------------------------------------ */

/* ------------------------------------------------------------ */
/*					Object Class Declarations					*/
/* ------------------------------------------------------------ */



/* ------------------------------------------------------------ */
/*					Variable Declarations						*/

/* ------------------------------------------------------------ */

typedef union
{

    struct
    {
        uint8_t d0; //LSB
        uint8_t d1;
        uint8_t d2;
        uint8_t d3;
        uint8_t d4;
        uint8_t d5;
    };
    uint8_t b[6];

} display_data_t;
/* ------------------------------------------------------------ */
/*					Procedure Declarations						*/
/* ------------------------------------------------------------ */

void Set_Page_Address(uint8_t);
void Set_Column_Address(uint8_t);
void oled_writeData(uint8_t);

void oled_BackLightSet(bool);

void oled_init();

void oled_clear();

void oled_clearRow(uint8_t page);

void oled_setDisplay(oLED_DisplayMode_t);

void oled_displayOff(bool);

void oled_putChar(char k, uint8_t station_dot, uint8_t start_page);

void oled_putString(const char *string, uint8_t station_dot, uint8_t start_page);

void oled_putUint8(uint8_t number, uint8_t station_dot, uint8_t start_page);

void oled_putUint16(uint16_t number, uint8_t station_dot, uint8_t start_page);

/* ------------------------------------------------------------ */

#endif	// _SSD1306_H

/************************************************************************/