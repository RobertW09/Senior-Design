/*
 * File:   rpo_types.h
 * Author: Ryan
 *
 * Created on December 24, 2015, 4:34 PM
 */

#ifndef RPO_TYPES_H
#define	RPO_TYPES_H

#include <stdint.h>

//
//Input used to compute data types needed for project
//
#define RPO_ADC_BITS (10) // Number of bits in the ADC
#define RPO_ADC_SHIFT (2) // Initial left shift of ADC data
#define RPO_ADC_SIGN_CONVERSION (1) // Extra bit needed to convert to signed

#define RPO_LFSR_LENGTH (4) // Maximum length of the LFSR
#define RPO_DECIMATION (2) // Number of times the sequence is repeated for a correlated sample

#define RPO_FIRST_PASS_SAMPLES (8) // Pulse filter first pass
#define RPO_SECOND_PASS_SAMPLES (8) // Pulse flter second pass

//
// Calculation and definition of data types.
//

// http://stackoverflow.com/questions/6834868/macro-to-compute-number-of-bits-needed-to-store-a-number-n
#define NBITS2(n) ((n&2)?1:0)
#define NBITS4(n) ((n&(0xC))?(2+NBITS2(n>>2)):(NBITS2(n)))
#define NBITS8(n) ((n&0xF0)?(4+NBITS4(n>>4)):(NBITS4(n)))
#define NBITS16(n) ((n&0xFF00)?(8+NBITS8(n>>8)):(NBITS8(n)))
#define NBITS32(n) ((n&0xFFFF0000)?(16+NBITS16(n>>16)):(NBITS16(n)))
#define NBITS(n) (n==0?0:NBITS32(n)+1)

#define RPO_RAW_BITS (RPO_ADC_BITS + RPO_ADC_SHIFT + RPO_ADC_SIGN_CONVERSION)

#define RPO_CORRELATED_BITS (RPO_RAW_BITS + RPO_LFSR_LENGTH + RPO_DECIMATION)

#define RPO_FIRST_PASS_BITS NBITS(RPO_FIRST_PASS_SAMPLES)
#define RPO_SECOND_PASS_BITS NBITS(RPO_SECOND_PASS_SAMPLES)
#define RPO_LONG_BITS (((RPO_FIRST_PASS_BITS > RPO_SECOND_PASS_BITS) ? RPO_FIRST_PASS_BITS : RPO_SECOND_PASS_BITS) + RPO_CORRELATED_BITS)

#ifndef INT24_MAX 
// For portability
typedef int32_t int24_t;
#define int24_t int24_t
#endif

#if RPO_RAW_BITS <= 8
typedef int8_t RPO_RAW_INT_T;
#warning RPO_RAW_INT_T is int8_t

#elif RPO_RAW_BITS <= 16
typedef int16_t RPO_RAW_INT_T;
#warning RPO_RAW_INT_T is int16_t

#elif RPO_RAW_BITS <= 24
typedef int24_t RPO_RAW_INT_T;
#warning RPO_RAW_INT_T is int24_t

#elif RPO_RAW_BITS <= 32
typedef int32_t RPO_RAW_INT_T;
#warning RPO_RAW_INT_T is int32_t

#else
#error RPO_RAW_INT_T is too big.
#endif

#if RPO_CORRELATED_BITS <= 8
typedef int8_t RPO_CORRELATED_INT_T;
#warning RPO_CORRELATED_INT_T is int8_t

#elif RPO_CORRELATED_BITS <= 16
typedef int16_t RPO_CORRELATED_INT_T;
#warning RPO_CORRELATED_INT_T is int16_t

#elif RPO_CORRELATED_BITS <= 24
typedef int24_t RPO_CORRELATED_INT_T;
#warning RPO_CORRELATED_INT_T is int24_t

#elif RPO_CORRELATED_BITS <= 32
typedef int32_t RPO_CORRELATED_INT_T;
#warning RPO_CORRELATED_INT_T is int32_t

#else
#error RPO_CORRELATED_INT_T is too big.
#endif

#if RPO_LONG_BITS <= 8
typedef int8_t RPO_LONG_INT_T;
#warning RPO_LONG_INT_T is int8_t

#elif RPO_LONG_BITS <= 16
typedef int16_t RPO_LONG_INT_T;
#warning RPO_LONG_INT_T is int16_t

#elif RPO_LONG_BITS <= 24
typedef int24_t RPO_LONG_INT_T;
#warning RPO_LONG_INT_T is int24_t

#elif RPO_LONG_BITS <= 32
typedef int32_t RPO_LONG_INT_T;
#warning RPO_LONG_INT_T is int32_t

#else
#error RPO_LONG_INT_T is too big.
#endif

#endif	/* RPO_TYPES_H */

