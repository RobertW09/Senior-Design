/*******************************************************************************
 * millis
 *
 * Company:
 *  Microchip Technology Inc.
 *
 * File Name:
 *  millis.h
 *
 * Summary:
 *  Millisecond timer
 *
 * Description:
 *  Provides a monotonically increasing counter that ticks up every millisecond.
 *
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

/**
 * Abbreviations Used:
 * MILLIS - Millisecond
 * Especially those used in function and variable names.
 */

#ifndef MILLIS_H    // Guards against multiple inclusion
#define MILLIS_H

/**
 * Section: Included Files
 */

#include <stdbool.h>
#include <stdint.h>

/**
 * Section: Data Types
 */

typedef uint32_t millis_t;

/**
 * Section: Millis APIs
 */

/**
 *
 * @Summary
 *  Initializes the millisecond timer
 *
 * @Description
 *  Returns the number of milliseconds since the module was initialized or last
 *  reset.
 *
 * @Preconditions
 *  This software timer requires a hardware timer
 *
 * @Params
 *  None
 *
 * @Returns
 *  err - true - An error occurred and the module is not correctly configured
 *        false - module is configured correctly
 *
 * @Comment
 *  None
 *
 * @Example
 *   <code>
 *   bool err = false;
 *   err |= MILLIS_Initialize(TMR2_SetInterruptHandler)
 *   ErrorCheck(err);
 *   </code>
 *
 * @See Also
 *
 */
bool MILLIS_Initialize(void (*CallbackSet)(void*));

/**
 *
 * @Summary
 *  Provides a delay of n milliseconds
 *
 * @Description
 *
 * @Preconditions
 *  MILLIS_Initialize should have been called before this functions.
 *
 * @Params
 *  None
 *
 * @Returns
 *  None
 *
 * @Comment
 *  None
 *
 * @Example
 *   <code>
 *   // Blocking blinky
 *   while(1) {
 *      LedOn();
 *      MILLIS_Delay(500); //wait 500 ms
 *      LedOff();
 *      MILLIS_Delay(500); //wait 500 ms
 *   }
 *   </code>
 *
 * @See Also
 *  MILLIS_Initialize()
 *  MILLIS_TimeGet()
 *
 */
void MILLIS_Delay(millis_t delay);

/**
 *
 * @Summary
 *  Gets number of milliseconds since last reset
 *
 * @Description
 *  Returns the number of milliseconds since the module was initialized or last
 *  reset.
 *
 * @Preconditions
 *  MILLIS_Initialize should have been called before this functions.
 *
 * @Params
 *  None
 *
 * @Returns
 *  millis_t - Count of milliseconds
 *
 * @Comment
 *  None
 *
 * @Example
 *   <code>
 *   // Non-blocking blinky
 *   lastToggle = 0;
 *   while(1) {
 *      currentTime = MILLIS_TimeGet();
 *      if(currentTime - lastToggle > 500) {
 *          LedToggle();
 *          lastToggle = currentTime;
 *      }
 *      StuffOtherDo();
 *   }
 *   </code>
 *
 * @See Also
 *  MILLIS_Initialize()
 *
 */
millis_t MILLIS_TimeGet(void);

#endif // FILE_NAME_H

/**
 * End of File
 */
