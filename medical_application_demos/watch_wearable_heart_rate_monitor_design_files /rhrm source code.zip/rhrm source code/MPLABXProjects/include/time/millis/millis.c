/*******************************************************************************
 * millis
 *
 * Company:
 *  Microchip Technology Inc.
 *
 * File Name:
 *  millis.h
 *
 * Summary:
 *  Millisecond timer
 *
 * Description:
 *  Provides a monotonically increasing counter that ticks up every millisecond.
 *
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

//
// Section: Included Files
//

#include <stdbool.h>
#include <stdint.h>
#include "millis.h"
#include "embed_assert/embed_assert.h"

//
// Section: Global Variable Declarations
//

// Counter for time keeping
volatile millis_t MILLIS_counter;

//
// Section: Static Function Prototypes
//

/**
 *
 * @Summary
 *  Callback function to pass to the hardware ISR function.
 *
 * @Description
 *
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  None
 *
 * @Returns
 *  None
 *
 * @Comment
 *  None
 *
 * @Example
 *  None
 *
 * @See Also
 *  MILLIS_Initialize()
 *
 */
void MILLIS_Callback(void);

//
// Section: Static Function Definitions
//

void MILLIS_Callback(void)
{
    MILLIS_counter++;
}

//
// Section: MILLIS APIs
//

bool MILLIS_Initialize(void (*CallbackSet)(void*))
{
    CallbackSet(MILLIS_Callback);
    return 0;
}

void MILLIS_Delay(const millis_t delay)
{
    millis_t i = MILLIS_TimeGet();
    while (delay > MILLIS_TimeGet() - i)
    {
        // Wait
    }
}

millis_t MILLIS_TimeGet(void)
{
    millis_t time;
    do
    {
        time = MILLIS_counter;
    }
    while (time != MILLIS_counter);
    return time;
}

//
// End of File
//
