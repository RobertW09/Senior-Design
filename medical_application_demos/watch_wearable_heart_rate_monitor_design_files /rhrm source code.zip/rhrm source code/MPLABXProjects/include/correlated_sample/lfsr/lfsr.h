/*******************************************************************************
 * Linear Feedback Shift Register (LFSR) API
 *
 * Company:
 *  Microchip Technology Inc.
 *
 * File Name:
 *  lfsr.h
 *
 * Summary:
 *  API for LFSR
 *
 * Description:
 *  This header file provides API for the LFSR.
 * 
 *  A LFSR is a shift register that provides feedback to the input to create a
 *  psuedorandom sequence.  Correctly configured, this sequence will be of
 *  maximal length.  In other words the shift register will hold every possible
 *  combination of values, except all 0s.
 * 
 *  https://en.wikipedia.org/wiki/Linear_feedback_shift_register
 *
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

/**
 * Abbreviations Used:
 * LFSR - Linear Feedback Shift Register
 * n - The number of bits in the LFSR
 */

#ifndef LFSR_H
#define	LFSR_H

//
// Section: Included Files
//

#include <stdbool.h>
#include <stdint.h>

//
// Section: Data Types
//

// Datatype for returning or storing the full value of the LFSR
typedef uint8_t lfsr_reg_t;

//
// Section: LFSR APIs
//
 
/**
 *
 * @Summary
 *  Initializes the LFSR
 *
 * @Description
 *  Initializes the LFSR
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  None
 *
 * @Returns
 *  Error -  False if no error occured.
 *
 * @Comment
 *  None
 *
 * @Example
 *  <code>
 *  // Example implementation
 *  bool LFSR_Initialize(void)
 *  {
 *      bool err = false;
 *
 *      // Set up the interrupts
 *      TMR4_SetInterruptHandler(LFSR_Callback);
 *
 *      return err;
 *  }
 *  </code>
 *
 * @See Also
 *  None
 *  
 */
bool LFSR_Initialize(void);

lfsr_reg_t LFSR_FeedbackTapsGet(void);
bool LFSR_FeedbackTapsSet(lfsr_reg_t feedbackTaps);
 
uint8_t LFSR_LengthGet(void);
bool LFSR_LengthSet(uint8_t length);

/**
 *
 * @Summary
 *  Gets the entire value of the LFSR
 *
 * @Description
 *  Returns the current value of the LFSR
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  None
 *
 * @Returns
 *  Current LFSR value
 *
 * @Comment
 *  None
 *
 * @See Also
 *  LFSR_TapGet()
 *  
 */
lfsr_reg_t LFSR_RegisterGet(void);
 
/**
 *
 * @Summary
 *  Starts the LFSR running
 *
 * @Description
 *  Starts the LFSR running
 *
 * @Preconditions
 *  LFSR should be inititialized
 *
 * @Params
 *  None
 *
 * @Returns
 *  None
 *
 * @Comment
 *
 * @See Also
 *  LFSR_Initialize
 *  LFSR_Stop
 *  
 */
bool LFSR_Start(void);
 
/**
 *
 * @Summary
 *  Stops the LFSR
 *
 * @Description
 *  Stops the operation to the LFSR.
 *
 * @Preconditions
 *  LFSR should be running.
 *
 * @Params
 *  None
 *
 * @Returns
 *  Error
 *
 * @Comment
 *  None
 *
 * @See Also
 *  LFSR_Start
 *  
 */
bool LFSR_Stop(void);

#endif	/* LFSR_H */

