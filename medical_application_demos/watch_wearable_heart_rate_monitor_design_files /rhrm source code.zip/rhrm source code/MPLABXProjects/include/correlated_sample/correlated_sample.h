/*
 * File:   pulse_oximeter.h
 * Author: C15140
 *
 * Created on October 15, 2015, 12:56 PM
 */

#ifndef CORRELATED_SAMPLE_H
#define	CORRELATED_SAMPLE_H

/**
  Section: Included Files
 */

#include <stdbool.h>
#include "types/rpo_types.h"

/**
  Section: Correlated Sample APIs
 */

// Performs required initialization for the correlation filter
bool CS_Initialize(void);

// clears previous correlation results
void CS_CorrelationClear(void);

// Checks if correlation is complete
bool CS_CorrelationDone(void);

// starts correlation of a new sample
bool CS_CorrelationStart(void);

// Stops correlation of current sample
bool CS_CorrelationStop(void);

// Gets correlation sample results
RPO_CORRELATED_INT_T CS_ResultRedGet(void);
RPO_CORRELATED_INT_T CS_ResultIRGet(void);
RPO_CORRELATED_INT_T CS_ResultGreenGet(void);
RPO_CORRELATED_INT_T CS_ResultBkgGet(void);

#endif	/* PULSE_OXIMETER_H */
