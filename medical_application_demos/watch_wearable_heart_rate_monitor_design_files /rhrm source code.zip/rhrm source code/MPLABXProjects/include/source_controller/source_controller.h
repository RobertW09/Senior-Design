/*******************************************************************************
 * Source Controller
 *
 * Company:
 *  Microchip Technology Inc.
 *
 * File Name:
 *  source_controller.h
 *
 * Summary:
 *  Provides API for source controller.
 *
 * Description:
 *  Source controller provides a means to level out the sensor response from
 *  multiple light sources.
 *
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

/**
 * Abbreviations Used:
 * SOCON - Source Controller
 * Especially those used in function and variable names.
 */

#ifndef SOURCE_CONTROLLER_H    // Guards against multiple inclusion
#define SOURCE_CONTROLLER_H

//
// Section: Included Files
//

#include <stdbool.h>
#include <stdint.h>
#include "types/rpo_types.h"

//
// Section: Source controller APIs
//

//Initilizer function for the source controller
bool SOCON_Initialize(void);

/*
 * Source control feedback function.
 * Provides latest data to source controller for feedback.
 */
bool SOCON_SourceFeedback(int24_t *data);

#endif // FILE_NAME_H

//
// End of File
//
