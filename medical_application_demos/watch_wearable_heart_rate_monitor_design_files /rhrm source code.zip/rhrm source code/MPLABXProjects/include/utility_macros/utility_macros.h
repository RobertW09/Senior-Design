/*******************************************************************************
 * Utility Macros
 *
 * Company:
 *  Microchip Technology Inc.
 *
 * File Name:
 *  utility_macros.h
 *
 * Summary:
 *  Assorted useful macros
 *
 * Description:
 *  This header file contains an assortment of useful macros.
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

/**
 * Abbreviations Used:
 * SFR: Special Function Register
 */

#ifndef UTILITY_MACROS_H    // Guards against multiple inclusion
#define UTILITY_MACROS_H

/**
 * Section: Macros
 */

/**
 *
 * @Summary
 *  Increments array index with wrap-around
 *
 * @Description
 *  Safe method for incrementing an aray index with boundary check
 *
 * @Preconditions
 *  To be used on index values to defined arrays.
 *
 * @Params
 *  a - Index value to be incramented
 *  b - Maximum LEGAL value for array index (size - 1)
 *
 * @Returns
 *  a + 1 if a +1 is legal, otherwise, 0.
 *
 * @Comment
 *  Useful for FIFO buffers
 *
 * @Example
 *   <code>
 *      TX1REG = eusartTxBuffer[eusartTxTail];
 *      eusartTxTail = UTIL_IndexIncrament(eusartTxTail, EUSART_TX_BUFFER_MAX);
 *   </code>
 */
#define UTIL_IndexIncrament(a,b) ((a) < (b) ? (a + 1) : (0))

/**
 *
 * @Summary
 *  Forces the desired typecast
 *
 * @Description
 *  Uses pointer casting to force the desired type cast.
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  a - type to cast to
 *  b - variable to typecast
 *
 * @Returns
 *  Typecasted variable
 *
 * @Comment
 *  Don't use this macro.  Do as I say, not as I do.
 *
 * @Example
 *   <code>
 *      TX1REG = eusartTxBuffer[eusartTxTail];
 *      eusartTxTail = UTIL_IndexIncrament(eusartTxTail, EUSART_TX_BUFFER_MAX);
 *   </code>
 */
#define UTIL_NoReallyDoThisTypeCastIThinkIKnowWhatImDoing(a, b) (* (a *) & b)

/**
 *
 * @Summary
 *  Adjusts a value to line up with the SFR position and mask.
 *
 * @Description
 *  Given the
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  a - Register and mask part of mask and posn definitions (e.g. _BAUD1CON_SCKP for _BAUD1CON_SCKP_MASK and _BAUD1CON_SCKP_POSN)
 *  b - Value to assign to SFR.
 *
 * @Returns
 *  A shifted and masked for of value b to line up in the SFR.
 *
 * @Comment
 *  Useful for making definitions for SFR settings.
 *
 * @Example
 *   <code>
 *   #define BAUD1CON_SCKP_NON_FALLING UTIL_SFR_SET(_BAUD1CON_SCKP, 0)
 *   </code>
 */
#define UTIL_SfrSet(a,b) ((a ## _MASK) & ((b) << (a ## _POSN)))

// Do not use these directly
#define _LAT(a) LAT ## a
#define _TRIS(a) TRIS ## a
#define _ANS(a) ANS ## a
#define _READ(a) R ## a

/**
 *
 * @Summary
 *  I/O pin interface macros
 *
 * @Description
 *  These macros make interfacing I/O easier.
 *  
 *  You can use a #define to define the I/O pin with a custom label like
 *      #define MY_BUTTON A0
 * 
 *  This define shows that you have a button on pin A0.
 * 
 *  Now, you can set the pin as an input in main
 *  <code>
 *  void main(void)
 *  {
 *      UTIL_TRIS(MY_BUTTON) = 1; // Define A0 as input
 *      UTIL_ANS(MY_BUTTON) = 0; // Disable analog; make digital input
 *      while(1)
 *      {
 *          if (0 == UTIL_READ(MY_BUTTON))
 *          {
 *              // Do Stuff
 *          }
 *      }
 *  }
 *  </code>
 * 
 *  The preprocessor turns that code into this: 
 * 
 * <code>
 *  void main(void)
 *  {
 *      TRISA0 = 1; // Define A0 as input
 *      ANSA0 = 0; // Disable analog; make digital input
 *      while(1)
 *      {
 *          if (0 == RA0)
 *          {
 *              // Do Stuff
 *          }
 *      }
 *  }
 *  </code>
 * 
 * That way, there's only 1 definition that describes that I/O pin instead of 3
 * (e.g. #define MY_BUTTON_LAT LATA0).
 *
 * @Preconditions
 *  None
 *
 * @Params
 *  a - I/O pin label or definition (e.g. A0 or MY_BUTTON in the example above)
 *
 * @Returns
 *  N/A
 *
 * @Comment
 *
 * @Example
 *  See above
 */
#define UTIL_LAT(a) _LAT(a)
#define UTIL_TRIS(a) _TRIS(a)
#define UTIL_ANS(a) _ANS(a)
#define UTIL_READ(a) _READ(a)


#endif // UTILITY_MACROS_H

/**
 * End of File
 */
