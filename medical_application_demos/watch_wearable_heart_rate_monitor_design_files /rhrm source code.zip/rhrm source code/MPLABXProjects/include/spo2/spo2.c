/*******************************************************************************
 * SPO2
 *
 * Company:
 *  Microchip Technology Inc.
 *
 * File Name:
 *  spo2.c
 *
 * Summary:
 *  Implementation of spo2 lookup
 *
 * Description:
 *  Provides means to convert sensor rations to o2 sat levels.
 *
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

//
// Section: Included Files
//
 
#include "spo2.h"
#include <stdbool.h>
#include <stdint.h>
#include "embed_assert/embed_assert.h"

//
// Section: Constants
//

extern const uint16_t SPO2_LOOKUP[SPO2_TABLE_LENGTH][2];

//
// Section: Template Module APIs
//

uint16_t SPO2_O2SatLookup(uint16_t ratio)
{
    uint16_t first = 0;
    uint16_t last = SPO2_TABLE_LENGTH - 1;
    while (first != last)
    {
        uint16_t mid = (first + last) >> 1;
        uint16_t midRatio = SPO2_LOOKUP[mid][0];
        if (ratio == midRatio)
        {
            first = mid;
            break;
        }
        else if (ratio > midRatio)
        {
            first = mid + 1;
        }
        else
        {
            last = mid - 1;
        }
    }

    // Assert first is a legal value
    E_ASSERT(SPO2_TABLE_LENGTH > first);

    return SPO2_LOOKUP[first][1];
}

//
// End of File
//
