/*******************************************************************************
 * SPO2
 *
 * Company:
 *  Microchip Technology Inc.
 *
 * File Name:
 *  spo2.h
 *
 * Summary:
 *  API for spo2 lookup
 *
 * Description:
 *  Provides means to convert sensor rations to o2 sat levels.
 *
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

/**
 * Abbreviations Used:
 * SPO2 - Peripheral Oxygen Saturation
 */

#ifndef SPO2_H    // Guards against multiple inclusion
#define SPO2_H

//
// Section: Included Files
//

#include <stdbool.h>
#include <stdint.h>

//
// Section: Constants
//

#define SPO2_FIRST_ENTRY (99)
#define SPO2_LAST_ENTRY (35)
#define SPO2_TABLE_LENGTH (SPO2_FIRST_ENTRY - SPO2_LAST_ENTRY + 1)

//
// Section: Data Types
//

//
// Section: SPO2 Lookup APIs
//
 
/**
 * Looks up SPO2 level based on sensor ratio
 * @param ratio in the form of ((sensor1 * 100) / sensor2)
 * @return SPO2 level in percent (0-99)
 * @comments Not qualified to give medical advice, but you might be dead if this
 * returns 0.
 */
uint16_t SPO2_O2SatLookup(uint16_t ratio);

#endif // SPO2_H

//
// End of File
//
 