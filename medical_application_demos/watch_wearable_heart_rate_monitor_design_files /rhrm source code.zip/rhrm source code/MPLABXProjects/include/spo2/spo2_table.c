/*******************************************************************************
 * SPO2 Lookup Table
 * 
 * Company:
 *  Microchip Technology Inc.
 * 
 * File Name:
 *  spo2_table.c
 * 
 * Summary:
 *  Lookup table for SPO2 result.
 * 
 * Description:
 *  Lookup table to convert ratio measurement to SPO2.
 * 
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

//
// Section: Included Files
//
 
#include "spo2.h"
#include <stdint.h>

//
// Section: Constants
//

// Lookup table for converting a ratio value (given as a percent) to peripheral
// oxygen saturation (also given as a percent).
// {<ratio>, <SPO2>}
const uint16_t SPO2_LOOKUP[SPO2_TABLE_LENGTH][2] = {
    {55, 99},
    {60, 98},
    {65, 97},
    {67, 96},
    {69, 95},
    {70, 94},
    {72, 93},
    {75, 92},
    {78, 91},
    {81, 90},
    {84, 89},
    {87, 88},
    {90, 87},
    {92, 86},
    {95, 85},
    {98, 84},
    {100, 83},
    {103, 82},
    {105, 81},
    {108, 80},
    {111, 79},
    {113, 78},
    {116, 77},
    {118, 76},
    {121, 75},
    {124, 74},
    {126, 73},
    {129, 72},
    {131, 71},
    {133, 70},
    {136, 69},
    {138, 68},
    {140, 67},
    {142, 66},
    {145, 65},
    {147, 64},
    {149, 63},
    {151, 62},
    {154, 61},
    {156, 60},
    {158, 59},
    {160, 58},
    {163, 57},
    {166, 56},
    {169, 55},
    {172, 54},
    {175, 53},
    {178, 52},
    {181, 51},
    {184, 50},
    {187, 49},
    {190, 48},
    {194, 47},
    {197, 46},
    {200, 45},
    {204, 44},
    {208, 43},
    {211, 42},
    {215, 41},
    {219, 40},
    {222, 39},
    {227, 38},
    {231, 37},
    {234, 36},
    {235, 35}
};

//
// End of File
//
