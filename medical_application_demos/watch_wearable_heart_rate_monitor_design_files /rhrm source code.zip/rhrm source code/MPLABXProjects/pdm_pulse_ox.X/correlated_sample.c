/**
 * Abbreviations Used:
 * BKG = Background
 * CS = Correlated Sample
 * LFSR = Linear Feedback Shift Register
 * RPO = Reflectance Pulse Oximetry
 */

/**
  Section: Included Files
 */

#include "correlated_sample/correlated_sample.h"
#include "mcc_generated_files/mcc.h"
#include "correlated_sample/lfsr/lfsr.h"
#include <stdbool.h>
#include <stdio.h>

//#define NDEBUG  // Comment line to compile assert statements
#include "embed_assert/embed_assert.h"

/**
  Section: Constants
 */

// Amount of oversampling / decimation
#define CS_REPEAT_COUNT (2)

// Taps = CLC number - 1.
//#define CS_TAP_RED (1) // LC2
//#define CS_TAP_IR1 (2) // LC3
//#define CS_TAP_IR2 (3) // LC4
//#define CS_TAP_BKG (0) // LC1

#define CS_TAP_RED   (3) // LC4
#define CS_TAP_IR    (2) // LC3
#define CS_TAP_GREEN (1) // LC2 - Green
#define CS_TAP_BKG   (0) // LC1

#define CS_Correlate(a, b) ((1 == (b)) ? (a) : -(a))
#define CS_TapShift(a, b) (((a) >> (b)) & 0x01)

#define CS_CorrelationIsDone() (CS_sampleMax == CS_sampleCount)
#define CS_CorrelationDisable() (CS_sampleCount = CS_sampleMax)
#define CS_CorrelationEnable() (CS_sampleCount = 0)


/**
  Section: Global Variables Definitions
 */

static uint16_t CS_sampleCount; // total samples accumulated
static uint16_t CS_sampleMax; // samples to accumulate for each correlation
static RPO_CORRELATED_INT_T CS_accumulatorRed;
static RPO_CORRELATED_INT_T CS_accumulatorIR;
static RPO_CORRELATED_INT_T CS_accumulatorGreen;
static RPO_CORRELATED_INT_T CS_accumulatorBkg;

static bool bkgTap;
static bool irTap;
static bool greenTap;
static bool redTap;

/**
  Section: Helper Prototypes
 */

/**
 * Callback function to be run for every ADC sample.
 * Accumulates correlated results
 */
static void CS_AdcCallback(void);
static void CS_ClockCallback(void);

/**
  Section: Correlated Sample Module APIs
 */

bool CS_Initialize(void)
{
    bool err = false;

    // Get the length of the LFSR
    uint8_t lfsrLength = LFSR_LengthGet();

    // Calculate the number of samples to take
    // 2 ^ lfsr length - 1
    CS_sampleMax = 1 << lfsrLength;
    CS_sampleMax -= 1;
    CS_sampleMax *= CS_REPEAT_COUNT;
    // CS_sampleMax += 13; // It's important to correlate over the entire pattern.

    // It's important to correlate over the entire pattern.
    // CS_sampleMax += 13; // Uncomment this line to see impact of a partial correlation

    // Disable correlation ... mark correlation done.
    CS_CorrelationDisable();

    // Clear correlation results / initialize memory
    CS_CorrelationClear();

    return err;
}

void CS_CorrelationClear(void)
{
    CS_accumulatorRed = 0;
    CS_accumulatorIR = 0;
    CS_accumulatorGreen = 0;
    CS_accumulatorBkg = 0;
}

bool CS_CorrelationDone(void)
{
    return CS_CorrelationIsDone();
}

bool CS_CorrelationStart(void)
{
    bool err = false;
//HEART_BEAT_SetHigh();
    // Get conversion to switch sensors.  Cast to void to throw away result.
    (void) ADC_GetConversion(channel_AN1);

    // Provide callback function that gets called on PWM interrupt
    err |= PWM1_CallbackSet(CS_ClockCallback);
    E_ASSERT(false == err);

    // Provide callback function that gets called on ADC interrupt
    err |= ADC_CallbackSet(CS_AdcCallback);
    E_ASSERT(false == err);

    // Set sampleCount to 0 to start the correlation
    CS_CorrelationEnable();
//HEART_BEAT_SetLow();
    return err;
}

bool CS_CorrelationStop(void)
{
    bool err = false;

    // Clear the callback from the PWM interrupt.
    err |= PWM1_CallbackClear(CS_ClockCallback);
    E_ASSERT(false == err);

    // Clear the callback from the ADC interrupt.
    err |= ADC_CallbackClear(CS_AdcCallback);
    E_ASSERT(false == err);

    // Stop correlation
    CS_CorrelationDisable();

    return err;
}

//TODO: These Result___Get functions should be combined into one function

RPO_CORRELATED_INT_T CS_ResultRedGet(void)
{
    return -CS_accumulatorRed; // Invert to get traditional pulse shape
}

RPO_CORRELATED_INT_T CS_ResultIRGet(void)
{
    return -CS_accumulatorIR;
}

RPO_CORRELATED_INT_T CS_ResultGreenGet(void)
{
    return -CS_accumulatorGreen;
}

RPO_CORRELATED_INT_T CS_ResultBkgGet(void)
{
    return -CS_accumulatorBkg;
}

static void CS_ClockCallback(void)
{
    // Get the current LFSR value.
    lfsr_reg_t taps = LFSR_RegisterGet();

    // Assign the current status of each tap.
    redTap = CS_TapShift(taps, CS_TAP_RED);
    irTap = CS_TapShift(taps, CS_TAP_IR);
    greenTap = CS_TapShift(taps, CS_TAP_GREEN);
    bkgTap = CS_TapShift(taps, CS_TAP_BKG);
}

static void CS_AdcCallback(void)
{
    if (CS_sampleMax > CS_sampleCount)
    {
        adc_result_t rawSample = ADC_GetConversionResult(); // Read sample
        RPO_RAW_INT_T shiftedSample = rawSample <<= 2; // Shift for extra precision after filtering

        // Correlate adc sample with LFSR taps
        CS_accumulatorRed += CS_Correlate(shiftedSample, redTap);
        CS_accumulatorIR += CS_Correlate(shiftedSample, irTap);
        CS_accumulatorGreen += CS_Correlate(shiftedSample, greenTap);
        CS_accumulatorBkg += CS_Correlate(shiftedSample, bkgTap);

        // Count number of samples correlated so far.
        CS_sampleCount++;
    }
    else
    {
        // Stop correlation when done
        bool err = CS_CorrelationStop();
        E_ASSERT(false == err);
    }
}
