
#pragma warning disable 752 // Conversion to shorter data type
#pragma warning disable 520 // function "<function name>" is never called
//#pragma warning disable 1395 // notable code sequence candidate suitable for compiler validation suite detected (1469)
