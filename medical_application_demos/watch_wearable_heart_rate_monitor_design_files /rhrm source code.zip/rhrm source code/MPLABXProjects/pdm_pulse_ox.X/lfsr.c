
//
// Section: Included Files
//
#include "correlated_sample/lfsr/lfsr.h"
#include "mcc_generated_files/mcc.h"

#define PDM

//
// Section: LFSR APIs
//

bool LFSR_Initialize(void)
{
    // Hardware initialized by MCC, so nothing to do here.
    return false;
}

lfsr_reg_t LFSR_FeedbackTapsGet(void)
{
    return 0x03U; // 0b0011
}

bool LFSR_FeedbackTapsSet(lfsr_reg_t feedbackTaps)
{
    return 1; // not implemented, return error
}

uint8_t LFSR_LengthGet(void)
{
    return 4U;
}

bool LFSR_LengthSet(uint8_t length)
{
    return 1; // not implemented, return error
}

lfsr_reg_t LFSR_RegisterGet(void)
{
    return (lfsr_reg_t) CLCDATA;
}

bool LFSR_Start(void)
{
    bool err = false;

    // Force CLC1 to output high.
    CLC1_OutputSet(1);

    // Wait for CLC2 to output high.
    int timeout = 10000;
    while (0 == CLC2_OutputStatusGet())
    {
        if (0 == --timeout)
        {
            // Took too long so something must be wrong.
            err |= true;
            break;
        }
    }

    // Reinitialize CLC1 with configuration from MCC.
#ifdef PDM
    CLC1_Initialize();
#elif defined TDM
    CLC1_InitializeTDM();
#else
#    error define either PDM or TDM
#endif

    // return err;
    return (err ? true : false);
}

bool LFSR_Stop(void)
{
    CLC1_OutputSet(0);
    return false;
}
