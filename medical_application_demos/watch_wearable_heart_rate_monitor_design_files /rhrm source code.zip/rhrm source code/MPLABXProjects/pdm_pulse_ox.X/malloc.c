/*******************************************************************************
 * MALLOC
 * 
 * Company:
 *  Microchip Technology Inc.
 * 
 * File Name:
 *  malloc.c
 * 
 * Summary:
 *  
 * 
 * Description:
 *  
 * 
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

//
// Section: Included Files
//

#include <stdlib.h>
#include "embed_assert/embed_assert.h"
#include <stdio.h>
#include <stddef.h>

//
// Section: Constants
//

// Size of heap space needed for the application.
#define MALLOC_HEAP_SIZE (256+512)
// Verbose malloc outputs additional information when called
#define MALLOC_VERBOSE (0)

//
// Section: Global Variables Definitions
//

// Storage array to allocate space from
static char MALLOC_heap[MALLOC_HEAP_SIZE];

// Indicates next available spot in heap for next allocation
int MALLOC_index = 0;

void *malloc(size_t size)
{
    void *ptr = NULL;
    if ((MALLOC_HEAP_SIZE - MALLOC_index) >= size)
    {
        ptr = &MALLOC_heap[MALLOC_index];
        MALLOC_index += size;
    }
    else
    {
        E_ASSERT(0);
    }
#if  1 == MALLOC_VERBOSE
    printf("Assigned ptr: %d \tNext ptr: %d \tMax: %d\r\n", (ptr - MALLOC_heap), MALLOC_index, MALLOC_HEAP_SIZE);
#endif
    return ptr;
}

// TODO: Haven't tested free()

void free(void *ptr)
{
    if (NULL == ptr)
    {
        return;
    }
    ptrdiff_t index = (char*) ptr - MALLOC_heap;
    if (index < MALLOC_index)
    {
        MALLOC_index = index;
    }
#if  1 == MALLOC_VERBOSE
    printf("Freed ptr: %d \tNext ptr: %d \tMax: %d\r\n", index, MALLOC_index, MALLOC_HEAP_SIZE);
#endif
}
