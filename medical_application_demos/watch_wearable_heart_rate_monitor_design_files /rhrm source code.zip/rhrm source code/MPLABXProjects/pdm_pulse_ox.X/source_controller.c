/*******************************************************************************
 * Source Controller
 * 
 * Company:
 *  Microchip Technology Inc.
 * 
 * File Name:
 *  source_controller.c
 * 
 * Summary:
 *  Evens out light sources used in sensor.
 * 
 * Description:
 *  This module takes input from the sensor.  It uses the source control
 *  functions to adjust the light sources to ensure a roughly even response from
 *  all sources.
 * 
 ******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2016 Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

//
// Section: Included Files
//

#include "source_controller/source_controller.h"
#include <stdbool.h>
#include <stdint.h>
#include "embed_assert/embed_assert.h"
#include "mcc_generated_files/mcc.h"
#include "debug_print/debug_print.h"

//
// Section: Constants
//

// Max value that can be supplied to the DAC
#define SOCON_SOURCE_MAX (1023)
#define SOCON_SOURCE_MID (SOCON_SOURCE_MAX / 2 + 1)

/**
 * Target response for the primary source.  Brightness of the source will be
 * adjusted to get the response close to this value. (+/- 1 threshold).  All
 * other sources will be tuned to math the first.
 */
#define SOCON_RESPONSE_TARGET (64000L)

// Threshold levels.
#define SOCON_THRESHOLD_BASE (200L)
#define SOCON_THRESHOLD_FINE (SOCON_THRESHOLD_BASE * 2L)
#define SOCON_THRESHOLD_COARSE (SOCON_THRESHOLD_BASE * 3L)

// Number of light sources used in sensor application
#define SOCON_SOURCE_COUNT (3)

//
// Section: Data Types
//

typedef uint16_t(*socon_source_read_t)(void); // Function to read current DAC setting
typedef void (*socon_source_write_t)(uint16_t); // Function to write new DAC setting

// Sensor adjustment state

typedef enum
{
    SOCON_ADJUST_NONE,
    SOCON_ADJUST_FINE,
    SOCON_ADJUST_COARSE,
    SOCON_ADJUST_MAX,
    SOCON_ADJUST_INVALID
} socon_state_t;

//
// Section: Global Variable Declarations
//

// TODO: These arrays can be consolidated into an array of structures.
// Source read function prototypes
socon_source_read_t SOCON_SourceRead[SOCON_SOURCE_COUNT] = {
    DAC5_Read10BitInputData,
    DAC6_Read10BitInputData
//    DAC1_Read10BitInputData,
//    DAC2_Read10BitInputData
};

socon_source_write_t SOCON_SourceWrite[SOCON_SOURCE_COUNT] = {
    DAC5_Load10bitInputData,
    DAC6_Load10bitInputData
//    DAC1_Load10bitInputData,
//    DAC2_Load10bitInputData
};

socon_state_t SOCON_sourceState[SOCON_SOURCE_COUNT] = {
    SOCON_ADJUST_MAX,
    SOCON_ADJUST_NONE,
    SOCON_ADJUST_NONE
};

int16_t SOCON_sourceAdjustment[SOCON_SOURCE_COUNT] = {
    0,
    0,
    0
};

//
// Section: Macros
//

#define SOCON_AbsoluteValue(a) (0 > a ? -a : a) // Returns absolute value of a

//
// Section: Static Function Prototypes
//

static bool SOCON_SourceAdjustment(int8_t sign, int index);
static socon_state_t SOCON_StateUpdate(socon_state_t currentState, uint8_t thresholdViolation);
static uint8_t SOCON_ThresholdCheck(int24_t targetValue, int24_t data);

//
// Section: Static Function Definitions
//

static bool SOCON_SourceAdjustment(int8_t sign, int index)
{
    uint16_t sourceSetting = SOCON_SourceRead[index]();

    bool sourceAdjusted;

    switch (SOCON_sourceState[index])
    {
    case SOCON_ADJUST_NONE: // No adjustment to make
        sourceAdjusted = false;
        break;
    case SOCON_ADJUST_FINE: // Fine adjustment
        sourceAdjusted = true;
        sourceSetting += sign;
        break;
    case SOCON_ADJUST_COARSE: // coarse adjustment
        sourceAdjusted = true;
        switch (SOCON_sourceAdjustment[index])
        {
        case 0:
            SOCON_sourceAdjustment[index] = SOCON_SOURCE_MID;
            sign = 1;
            sourceSetting = 0;
        default: // Fall through from above.
            sourceSetting += SOCON_sourceAdjustment[index] * sign;
            SOCON_sourceAdjustment[index] /= 2;
            break;
        }
        break;
    case SOCON_ADJUST_MAX:
        sourceAdjusted = false;
        sourceSetting = SOCON_SOURCE_MAX;
        break;
    default:
        E_ASSERT(false);
        break;
    }
    SOCON_SourceWrite[index](sourceSetting);
    return sourceAdjusted;
}

static socon_state_t SOCON_StateUpdate(socon_state_t currentState, uint8_t thresholdViolation)
{
    switch (currentState)
    {
    case SOCON_ADJUST_NONE:
        switch (thresholdViolation)
        {
        case 0:
        case 1:
            currentState = SOCON_ADJUST_NONE;
            break;
        case 2:
            currentState = SOCON_ADJUST_FINE;
            break;
        case 3:
            currentState = SOCON_ADJUST_COARSE;
            break;
        default:
            E_ASSERT(false);
            while (1);
            break;
        }
        break;
    case SOCON_ADJUST_FINE:
    case SOCON_ADJUST_COARSE:
        switch (thresholdViolation)
        {
        case 0:
            currentState = SOCON_ADJUST_NONE;
            break;
        case 1:
            currentState = SOCON_ADJUST_FINE;
            break;
        case 2:
            currentState = SOCON_ADJUST_FINE;
            break;
        case 3:
            currentState = SOCON_ADJUST_COARSE;
            break;
        default:
            E_ASSERT(false);
            while (1);
            break;
        }
        break;
    case SOCON_ADJUST_MAX:
        currentState = SOCON_ADJUST_MAX;
        break;
    default:
        E_ASSERT(false);
        break;
    }
    return currentState;
}

static uint8_t SOCON_ThresholdCheck(int24_t targetValue, int24_t data)
{
    int24_t diff = targetValue - data;
    diff = SOCON_AbsoluteValue(diff);
    uint8_t check = diff > SOCON_THRESHOLD_BASE;
    check += diff > SOCON_THRESHOLD_FINE;
    check += diff > SOCON_THRESHOLD_COARSE;
    return check;
}

//
// Section: Source Controller APIs
//

bool SOCON_Initialize(void)
{
    return false; // Not implemented, no error.
}

bool SOCON_SourceFeedback(int24_t *data)
{
    bool adjustmentMade = false;
    for (int i = 0; i < SOCON_SOURCE_COUNT; i++)
    {
        uint8_t thresholdCheck;
        int8_t adjustmentDirection;
        if (0 == i)
        {
            thresholdCheck = SOCON_ThresholdCheck(SOCON_RESPONSE_TARGET, data[i]);
            adjustmentDirection = SOCON_RESPONSE_TARGET >= data[i] ? -1 : 1;
        }
        else
        {
            thresholdCheck = SOCON_ThresholdCheck(data[0], data[i]);
            adjustmentDirection = data[0] >= data[i] ? -1 : 1;
        }
        SOCON_sourceState[i] = SOCON_StateUpdate(SOCON_sourceState[i], thresholdCheck);
        adjustmentMade |= SOCON_SourceAdjustment(adjustmentDirection, i);
    }
    return adjustmentMade;
}

//
// End of File
//
