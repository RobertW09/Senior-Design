/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - 4.0
        Device            :  PIC16F1779
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.40
 */

/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

#include <pic16f1779.h>
#include <stdlib.h>
#include "mcc_generated_files/mcc.h"
#include "time/millis/millis.h"
#include "embed_assert/embed_assert.h"
#include "display/display.h"
#include "correlated_sample/correlated_sample.h"
#include "debug_print/debug_print.h"
#include "source_controller/source_controller.h"
#include "correlated_sample/lfsr/lfsr.h"
#include "pulse_detector/pulse_detector.h"
#include "pulse_detector/pulse_filter/pulse_filter.h"
#include "filters/Second Moving Average Filter/moving_average_filter.h"
#include "math.h"

#define LightIRBrightnessSet(x) DAC6_Load10bitInputData(x)
#define LightGreenBrightnessSet(x) DAC5_Load10bitInputData(x)

#define ADC_Sample_Rate 135
#define HR_number 4

#define Enable_UART_output
//#define ry_pulse_detection_routine
#define my_pulse_detection_routine

#define Sample_Window_Interval_down		27
#define Sample_Window_Interval_up		16
#define max_thershold   50

static void MAIN_ApplicationInitialize(void);
static bool MAIN_ButtonF1DebouncedRead(void);
static bool MAIN_ButtonF2DebouncedRead(void);
static void MAIN_DisplayDataPlot(int32_t data);
static void MAIN_DisplayDataPlot_green(int32_t data);
static void MAIN_DisplayDataPlot_ir(int32_t data);
static void MAIN_DisplayDataPlot_red(int32_t data);
static void MAIN_DisplayInit(void);
//bool MAIN_LightTouch(bool pressed, RPO_CORRELATED_INT_T sample);
static bool Find_MaxMin(int24_t ir, int24_t red, int24_t green);
void SpO2_Calculation (void);

int8_t Find_MaxMin_State;
int24_t data_max, data_min;
int16_t Sample_Window_Counter;
int8_t Pulse_Detection_Done;
int24_t green_pulse_max_value, green_pulse_min_value;
int24_t red_pulse_max_value, red_pulse_min_value;
int24_t ir_pulse_max_value, ir_pulse_min_value;

signed int IR_Vpp, Red_Vpp;
double IR_Vrms, Red_Vrms;
double Ratio;
unsigned char SpO2, SpO2_previous;

/*
    Main application
 */
void main(void)
{
    millis_t lastRateCheck = 0;
    int beatCount = 0;
    int heartRate = 0;
    bool press = false; // Assume the device is not pressed at first
    int first_reading = 0;
    int heartRate_previous = 0;
    
    MA2_Filter_t filter;
//    MA2_Filter_init(&filter, 10);
    int24_t filter_temp = 0;
    
    uint8_t HRcounter = 0;
    uint16_t Heart_Rate = 0;
    uint16_t HR_ADCcounter = 0;
    int24_t pulse_peak_value = 0;
    SpO2_previous = 99;
    Find_MaxMin_State = 0;
    buttonF2_pressed = 0;
    
    // initialize the device
    SYSTEM_Initialize();
    MAIN_ApplicationInitialize();

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    RPO_CORRELATED_INT_T redRaw = 0;
    PULSE_FILTER_T *redFilter = PF_FilterNew(14, 16);
    RPO_CORRELATED_INT_T redFiltered = 0;
    PD_DETECTOR_T *redPulseDetector = PD_DetectorNew(6);
    RPO_CORRELATED_INT_T redMin = 0;
    RPO_CORRELATED_INT_T redMax = 0;
    RPO_CORRELATED_INT_T redPeak = 0;
    
    RPO_CORRELATED_INT_T irRaw = 0;
    PULSE_FILTER_T *irFilter = PF_FilterNew(12, 14);    //10,12
    RPO_CORRELATED_INT_T irFiltered = 0;
    PD_DETECTOR_T *irPulseDetector = PD_DetectorNew(6);
    RPO_CORRELATED_INT_T irMin = 0;
    RPO_CORRELATED_INT_T irMax = 0;
    RPO_CORRELATED_INT_T irPeak = 0;

    RPO_CORRELATED_INT_T greenRaw = 0;
    PULSE_FILTER_T *greenFilter = PF_FilterNew(8, 10);     //4,6
    RPO_CORRELATED_INT_T greenFiltered = 0;
    PD_DETECTOR_T *greenPulseDetector = PD_DetectorNew(6);
    RPO_CORRELATED_INT_T greenMin = 0;
    RPO_CORRELATED_INT_T greenMax = 0;
    RPO_CORRELATED_INT_T greenPeak = 0;
    
    PD_DetectorDelete(greenPulseDetector);
    PF_FilterDelete(greenFilter);
    PD_DetectorDelete(irPulseDetector);
    PF_FilterDelete(irFilter);
    PD_DetectorDelete(redPulseDetector);
    PF_FilterDelete(redFilter);
    
    // Print column headers in first round through the loop
    DBP_PrintModeSet(DBP_HEADING);

    while (1)
    {
        millis_t currentTime_ms = MILLIS_TimeGet();
        
        // Check if correlation is done
        if (CS_CorrelationDone())
        {
            // Add your application code
//            oled_putUint8((uint8_t) (8 + (10%30)*4), 0, 4);
//            MILLIS_Delay(500);
//            HEART_BEAT_Toggle();
//            HEART_BEAT_SetHigh(); // Show Activity

            // Get timestamp
            millis_t timeStamp = MILLIS_TimeGet();
            
            // Get correlated results
            RPO_CORRELATED_INT_T redRaw = CS_ResultRedGet();
            RPO_CORRELATED_INT_T irRaw = CS_ResultIRGet();
            RPO_CORRELATED_INT_T greenRaw = CS_ResultGreenGet();
            RPO_CORRELATED_INT_T bkgRaw = CS_ResultBkgGet();
            
            // Clear the previous results and start the next correlation
            CS_CorrelationClear();
            CS_CorrelationStart();
            
            // Filter the data
            redFiltered = PF_SampleShift(redFilter, redRaw);
            irFiltered = PF_SampleShift(irFilter, irRaw);
            greenFiltered = PF_SampleShift(greenFilter, greenRaw);
            
            // Filter the data second time with second moving_average_filter
//            filter_temp = MA2_Filter(&filter, greenRaw);
            
            // Use sum of sensor results for heartbeat detection
//            RPO_CORRELATED_INT_T sum = redRaw + irRaw + greenRaw;
//            RPO_CORRELATED_INT_T sum = redFiltered + irFiltered + greenFiltered;
            
            // Provide feedback to light sources.
            // Check if adjustments were made.
//            bool adjusted = SOCON_SourceFeedback(sensorData);
            bool adjusted = 0;
            
//            press = MAIN_LightTouch(press, irRaw); // Check if sensor is touched
//            press = 120000 > currentTime_ms;
//            press &= 5000 < currentTime_ms;
            if (redRaw >= -10000)
            {
                if (greenRaw <= -15000)
                {
                    press = 1;
//                    HEART_BEAT_SetHigh();
                } else {
                    press = 0;
//                    HEART_BEAT_SetLow();
                }
            } else {
                press = 0;
//                HEART_BEAT_SetLow();
            }
            
            // Compute Heart Rate
//            if (press == true)      // if the sensor is pressed
            if (1)
            {
            #ifdef ry_pulse_detection_routine
                // Get pulse detection state
                PD_DETECTION_STATE_T detectionState = PD_PulseDetector(greenPulseDetector, greenFiltered);
                
                // Check for heart beat
                int heartBeat = (PD_PULSE_DETECTED == detectionState && 0 == adjusted);
            
                beatCount += heartBeat;
                if (10000 < currentTime_ms - lastRateCheck)
                {
                    heartRate = beatCount * 60;
                    heartRate /= 10;
                    beatCount = 0;
                    lastRateCheck = currentTime_ms;
                }
                
                // Display results on LCD
                oled_putString("   ", 0, 2);
                oled_putUint8((uint8_t) heartRate, 0, 2);
            #endif  //ry_pulse_detection_routine
                
            #ifdef my_pulse_detection_routine
//                filter_temp = DC_Filter(greenFiltered);
                // My pulse detection routine
//                pulse_peak_value = Find_MaxMin(filter_temp);
                Pulse_Detection_Done = Find_MaxMin(irFiltered, redFiltered, greenFiltered);

                if (Pulse_Detection_Done)   // if a peak is detected
                {
                    HEART_BEAT_SetHigh();
                    HRcounter++;
                    if (HRcounter == HR_number)     // For example, 4 heart beats (3 RR intervals) detected
                    {
                        Heart_Rate = 60 * (HR_number-1) * ADC_Sample_Rate / HR_ADCcounter;        // Heart_Rate = 60sec/(((1/ADCsampleRate)*HR_ADCcounter)/RRintervalNumber)
                        HR_ADCcounter = 0;
                        HRcounter = 0;

                        // gradually_display
                        if (((Heart_Rate - heartRate_previous) > 0) && ((Heart_Rate - heartRate_previous) < 10))
                        {
                            heartRate_previous++;
                        }
                        else if (((Heart_Rate - heartRate_previous) < 0) && ((Heart_Rate - heartRate_previous) > -10))
                        {
                            heartRate_previous--;
                        }
                        else {
                            heartRate_previous = Heart_Rate;
                        }
                        
                        first_reading++;
                        if (first_reading >= 3)
                            first_reading = 3;
                    }
                    
                    SpO2_Calculation();				//calculate SpO2
                    if (SpO2 > SpO2_previous)
					{
						SpO2 = SpO2_previous + 1;
						SpO2_previous = SpO2;
					}
					else if (SpO2 < SpO2_previous)
					{
						SpO2 = SpO2_previous - 1;
						SpO2_previous = SpO2;
					}
                }
                if (HRcounter >= 1)
                {
                    HR_ADCcounter++;
                }
                
                // Display results on LCD
                if (first_reading > 1)
                {
//                    oled_putString("   ", 10, 2);
//                    oled_putUint8((uint8_t) SpO2, 10, 2);  // SPO2
//                    oled_putString("   ", 10, 1);
//                    oled_putUint8((uint8_t) heartRate_previous, 10, 1);      // my heart rate
                    oled_putString("   ", 13, 0);
                    oled_putUint8((uint8_t) heartRate_previous, 13, 0);      // my heart rate
                }
            #endif  //my_pulse_detection_routine
            }
            else    // if the sensor is not pressed
            {
                beatCount = 0;
                lastRateCheck = currentTime_ms;
                heartRate = 0;
                heartRate_previous = 0;
                HR_ADCcounter = 0;
                HRcounter = 0;
                first_reading = 0;
                
                // Display zero on LCD
                oled_putString("   ", 0, 2);
                oled_putString("   ", 0, 1);
            }
            
            // Plot the sum on the display
//            MAIN_DisplayDataPlot(greenFiltered);

            switch(buttonF2_pressed)
            {
                case 0:
                    MAIN_DisplayDataPlot_green(greenFiltered);
                    MAIN_DisplayDataPlot_ir(irFiltered);
                    MAIN_DisplayDataPlot_red(redFiltered);
                    break;
                case 1:
                    oled_clear();
                    oled_putString("Green", 0, 0);
                    buttonF2_pressed = 2;
                    break;
                case 2:
                    MAIN_DisplayDataPlot(greenFiltered);
                    break;
                case 3:
                    oled_clear();
                    oled_putString("IR", 0, 0);
                    buttonF2_pressed = 4;
                    break;
                case 4:
                    MAIN_DisplayDataPlot(irFiltered);
                    break;
                case 5:
                    oled_clear();
                    oled_putString("RED", 0, 0);
                    buttonF2_pressed = 6;
                    break;
                case 6:
                    MAIN_DisplayDataPlot(redFiltered);
                    break;
                case 7:
                    oled_clear();
                    oled_putUint8((uint8_t) heartRate_previous, 13, 0);      // my heart rate
                    buttonF2_pressed = 0;
                    break;
                default:
                    oled_clear();
                    oled_putUint8((uint8_t) heartRate_previous, 13, 0);      // my heart rate
                    buttonF2_pressed = 0;
                    break;
            }
            // Bundle sensor data to perform feedback to light sources
//            RPO_CORRELATED_INT_T sensorData[3];
//            sensorData[0] = redRaw;
//            sensorData[1] = irRaw;
//            sensorData[2] = greenRaw;
            
//            RPO_CORRELATED_INT_T sensorData[3];
//            sensorData[0] = greenRaw;
//            sensorData[1] = greenFiltered;
//            sensorData[2] = pulse_peak_value;

            RPO_CORRELATED_INT_T sensorData[3];
            sensorData[0] = redFiltered;
            sensorData[1] = irFiltered;
            sensorData[2] = greenFiltered;
            
            #ifdef Enable_UART_output
            // Output data in columns
            DBP_DebugPrintInt("time_(ms)", timeStamp, 0);
            
            for (int i = 0; i < 3; i++)
            {
                switch (i)
                {
                case 0:
                    DBP_HeaderPrefixSet("red");
                    break;
                case 1:
                    DBP_HeaderPrefixSet("ir");
                    break;
                case 2:
                    DBP_HeaderPrefixSet("green");
                    break;
                default:
                    E_ASSERT(false);
                    break;
                }
                DBP_DebugPrintInt("Raw", sensorData[i], 0);
            }

            DBP_HeaderPrefixSet("");

//            DBP_DebugPrintInt("Raw", sensorData[1], 0); //send greenRaw only
//            DBP_DebugPrintInt("bkgRaw", bkgRaw, 1);
//            DBP_DebugPrintInt("sum", sum, 1);

            // Printout of DAC adjustment flag
//            DBP_DebugPrintInt("adjusted", adjusted, 0);

            // Print new line
            DBP_DebugPrintNewLine();

            // Switch to printing data after first loop through.
            DBP_PrintModeSet(DBP_DATA);
            #endif  //Disable_UART_output
        }

        while (EUSART_DataReady)
        {
            uint8_t readCh = EUSART_Read();
            switch (readCh)
            {
            case 'r':
                RESET();
                break;
            case 'p':
                // Pause and wait for a key press
                while (!EUSART_DataReady);
                break;
            default:
                // Do nothing
                break;
            }
        }
/*
        if (MAIN_ButtonF1DebouncedRead())
        {
            while (MAIN_ButtonF1DebouncedRead());
            RESET();
        }

        if (MAIN_ButtonF2DebouncedRead())
        {
            while (MAIN_ButtonF2DebouncedRead()); // Wait for release
            while (!MAIN_ButtonF2DebouncedRead()); // Wait for next press
            while (MAIN_ButtonF2DebouncedRead()); // Wait for re-release
        }
*/
        HEART_BEAT_SetLow();
    }
}

static void MAIN_ApplicationInitialize(void)
{
    // No parentheses to pass pointer
    MILLIS_Initialize(TMR2_SetInterruptHandler);

    // Initialize the LFSR
    LFSR_Initialize();
    LFSR_Start();

    MAIN_DisplayInit();

    DBP_VerboseLevelSet(0);

    // Initialize the correlated sample module
    CS_Initialize();

    LightGreenBrightnessSet(1000);
    LightIRBrightnessSet(1000);
}

static bool MAIN_ButtonF1DebouncedRead(void)
{
    static bool buttonF1State;
    static uint8_t buttonF1Debounce;
    buttonF1Debounce <<= 1;
    buttonF1Debounce |= (!BUTTON_F1_GetValue());
    switch (buttonF1State)
    {
    case 0:
        if (UINT8_MAX == buttonF1Debounce)
        {
            buttonF1State = 1;
        }
        break;
    case 1:
        if (0 == buttonF1Debounce)
        {
            buttonF1State = 0;
        }
        break;
    default:
        E_ASSERT(false);
        break;
    }
    return buttonF1State;
}

// Evil repeating functions!
static bool MAIN_ButtonF2DebouncedRead(void)
{
    static bool buttonF2State;
    static uint8_t buttonF2Debounce;
    buttonF2Debounce <<= 1;
    buttonF2Debounce |= (!BUTTON_F2_GetValue());
    switch (buttonF2State)
    {
    case 0:
        if (UINT8_MAX == buttonF2Debounce)
        {
            buttonF2State = 1;
        }
        break;
    case 1:
        if (0 == buttonF2Debounce)
        {
            buttonF2State = 0;
        }
        break;
    default:
        E_ASSERT(false);
        break;
    }
    return buttonF2State;
}

static void MAIN_DisplayDataPlot(int32_t data)
{
    // Display Constants
    const int PLOT_LINE_FIRST = 3;  //3
    const int PLOT_LINE_LAST = 7;   //7
    const int PLOT_LINE_COUNT = PLOT_LINE_LAST - PLOT_LINE_FIRST + 1;
    const int LINE_PIXEL_HEIGHT = 8;
    const int PLOT_PIXEL_HEIGHT = PLOT_LINE_COUNT * LINE_PIXEL_HEIGHT;
    const int PLOT_PIXEL_WIDTH = 128;

    // Display state variables
    static int dataCount;
    static int32_t dataSum;
    static int sweepIndex;
    static int32_t sweepMax;
    static int32_t sweepMin;
    static int32_t dispScale;
    static int32_t dispMin;

    dataCount++;
    dataSum -= data; // Flip the data for the display
    dataCount %= 4;
    if (0 == dataCount)
    {
        // Pulse sweep
        if (PLOT_PIXEL_WIDTH == sweepIndex)
        {
            int32_t dispMid = sweepMax + sweepMin;
            dispMid >>= 1;
            int32_t diff = sweepMax - sweepMin;
            int32_t dispHalfHeight = PLOT_PIXEL_HEIGHT / 2;
            int32_t scaler = PLOT_PIXEL_HEIGHT / 3;
            dispScale = diff / scaler;
            dispMin = dispMid - (diff * dispHalfHeight / scaler);
            E_ASSERT(dispMid <= sweepMax);
            E_ASSERT(dispMid >= sweepMin);
            E_ASSERT(dispMin <= sweepMin);

            sweepMin = sweepMax = dataSum;
            sweepIndex = 0;
        }
        else
        {
            sweepMin = (sweepMin > dataSum) ? dataSum : sweepMin;
            sweepMax = (sweepMax < dataSum) ? dataSum : sweepMax;
            sweepIndex++;
        }

        if (0 != dispScale)
        {
            dataSum -= dispMin;
            dataSum /= dispScale;
            if (0 <= dataSum && PLOT_PIXEL_HEIGHT > dataSum)
            {
                uint8_t pageAddress = dataSum / LINE_PIXEL_HEIGHT;
                pageAddress += PLOT_LINE_FIRST;
                uint8_t pixel = 1 << (dataSum % LINE_PIXEL_HEIGHT);
                Set_Page_Address(pageAddress);
                Set_Column_Address(sweepIndex);
                oled_writeData(pixel);
            }
        }

        // Erase the data ahead of the sweep.
        int eraseIndex = sweepIndex + 10;
        eraseIndex %= PLOT_PIXEL_WIDTH;
        Set_Column_Address(eraseIndex);
        for (int i = PLOT_LINE_FIRST; i < PLOT_LINE_FIRST + PLOT_LINE_COUNT; i++)
        {
            Set_Page_Address(i);
            oled_writeData(0x00);
        }

        dataSum = 0;
    }
}

static void MAIN_DisplayDataPlot_green(int32_t data)
{
    // Display Constants
    const int PLOT_LINE_FIRST = 0;  //3
    const int PLOT_LINE_LAST = 2;   //7
    const int PLOT_LINE_COUNT = PLOT_LINE_LAST - PLOT_LINE_FIRST + 1;
    const int LINE_PIXEL_HEIGHT = 8;
    const int PLOT_PIXEL_HEIGHT = PLOT_LINE_COUNT * LINE_PIXEL_HEIGHT;
    const int PLOT_PIXEL_WIDTH = 128;

    // Display state variables
    static int dataCount;
    static int32_t dataSum;
    static int sweepIndex;
    static int32_t sweepMax;
    static int32_t sweepMin;
    static int32_t dispScale;
    static int32_t dispMin;

    dataCount++;
    dataSum -= data; // Flip the data for the display
    dataCount %= 4;
    if (0 == dataCount)
    {
        // Pulse sweep
        if (PLOT_PIXEL_WIDTH == sweepIndex)
        {
            int32_t dispMid = sweepMax + sweepMin;
            dispMid >>= 1;
            int32_t diff = sweepMax - sweepMin;
            int32_t dispHalfHeight = PLOT_PIXEL_HEIGHT / 2;
            int32_t scaler = PLOT_PIXEL_HEIGHT / 3;
            dispScale = diff / scaler;
            dispMin = dispMid - (diff * dispHalfHeight / scaler);
            E_ASSERT(dispMid <= sweepMax);
            E_ASSERT(dispMid >= sweepMin);
            E_ASSERT(dispMin <= sweepMin);

            sweepMin = sweepMax = dataSum;
            sweepIndex = 0;
        }
        else
        {
            sweepMin = (sweepMin > dataSum) ? dataSum : sweepMin;
            sweepMax = (sweepMax < dataSum) ? dataSum : sweepMax;
            sweepIndex++;
        }

        if (0 != dispScale)
        {
            dataSum -= dispMin;
            dataSum /= dispScale;
            if (0 <= dataSum && PLOT_PIXEL_HEIGHT > dataSum)
            {
                uint8_t pageAddress = dataSum / LINE_PIXEL_HEIGHT;
                pageAddress += PLOT_LINE_FIRST;
                uint8_t pixel = 1 << (dataSum % LINE_PIXEL_HEIGHT);
                Set_Page_Address(pageAddress);
                Set_Column_Address(sweepIndex);
                oled_writeData(pixel);
            }
        }

        // Erase the data ahead of the sweep.
        int eraseIndex = sweepIndex + 10;
        eraseIndex %= PLOT_PIXEL_WIDTH;
        Set_Column_Address(eraseIndex);
        for (int i = PLOT_LINE_FIRST; i < PLOT_LINE_FIRST + PLOT_LINE_COUNT; i++)
        {
            Set_Page_Address(i);
            oled_writeData(0x00);
        }

        dataSum = 0;
    }
}

static void MAIN_DisplayDataPlot_ir(int32_t data)
{
    // Display Constants
    const int PLOT_LINE_FIRST = 3;  //3
    const int PLOT_LINE_LAST = 5;   //7
    const int PLOT_LINE_COUNT = PLOT_LINE_LAST - PLOT_LINE_FIRST + 1;
    const int LINE_PIXEL_HEIGHT = 8;
    const int PLOT_PIXEL_HEIGHT = PLOT_LINE_COUNT * LINE_PIXEL_HEIGHT;
    const int PLOT_PIXEL_WIDTH = 128;

    // Display state variables
    static int dataCount;
    static int32_t dataSum;
    static int sweepIndex;
    static int32_t sweepMax;
    static int32_t sweepMin;
    static int32_t dispScale;
    static int32_t dispMin;

    dataCount++;
    dataSum -= data; // Flip the data for the display
    dataCount %= 4;
    if (0 == dataCount)
    {
        // Pulse sweep
        if (PLOT_PIXEL_WIDTH == sweepIndex)
        {
            int32_t dispMid = sweepMax + sweepMin;
            dispMid >>= 1;
            int32_t diff = sweepMax - sweepMin;
            int32_t dispHalfHeight = PLOT_PIXEL_HEIGHT / 2;
            int32_t scaler = PLOT_PIXEL_HEIGHT / 3;
            dispScale = diff / scaler;
            dispMin = dispMid - (diff * dispHalfHeight / scaler);
            E_ASSERT(dispMid <= sweepMax);
            E_ASSERT(dispMid >= sweepMin);
            E_ASSERT(dispMin <= sweepMin);

            sweepMin = sweepMax = dataSum;
            sweepIndex = 0;
        }
        else
        {
            sweepMin = (sweepMin > dataSum) ? dataSum : sweepMin;
            sweepMax = (sweepMax < dataSum) ? dataSum : sweepMax;
            sweepIndex++;
        }

        if (0 != dispScale)
        {
            dataSum -= dispMin;
            dataSum /= dispScale;
            if (0 <= dataSum && PLOT_PIXEL_HEIGHT > dataSum)
            {
                uint8_t pageAddress = dataSum / LINE_PIXEL_HEIGHT;
                pageAddress += PLOT_LINE_FIRST;
                uint8_t pixel = 1 << (dataSum % LINE_PIXEL_HEIGHT);
                Set_Page_Address(pageAddress);
                Set_Column_Address(sweepIndex);
                oled_writeData(pixel);
            }
        }

        // Erase the data ahead of the sweep.
        int eraseIndex = sweepIndex + 10;
        eraseIndex %= PLOT_PIXEL_WIDTH;
        Set_Column_Address(eraseIndex);
        for (int i = PLOT_LINE_FIRST; i < PLOT_LINE_FIRST + PLOT_LINE_COUNT; i++)
        {
            Set_Page_Address(i);
            oled_writeData(0x00);
        }

        dataSum = 0;
    }
}

static void MAIN_DisplayDataPlot_red(int32_t data)
{
    // Display Constants
    const int PLOT_LINE_FIRST = 6;  //3
    const int PLOT_LINE_LAST = 8;   //7
    const int PLOT_LINE_COUNT = PLOT_LINE_LAST - PLOT_LINE_FIRST + 1;
    const int LINE_PIXEL_HEIGHT = 8;
    const int PLOT_PIXEL_HEIGHT = PLOT_LINE_COUNT * LINE_PIXEL_HEIGHT;
    const int PLOT_PIXEL_WIDTH = 128;

    // Display state variables
    static int dataCount;
    static int32_t dataSum;
    static int sweepIndex;
    static int32_t sweepMax;
    static int32_t sweepMin;
    static int32_t dispScale;
    static int32_t dispMin;

    dataCount++;
    dataSum -= data; // Flip the data for the display
    dataCount %= 4;
    if (0 == dataCount)
    {
        // Pulse sweep
        if (PLOT_PIXEL_WIDTH == sweepIndex)
        {
            int32_t dispMid = sweepMax + sweepMin;
            dispMid >>= 1;
            int32_t diff = sweepMax - sweepMin;
            int32_t dispHalfHeight = PLOT_PIXEL_HEIGHT / 2;
            int32_t scaler = PLOT_PIXEL_HEIGHT / 3;
            dispScale = diff / scaler;
            dispMin = dispMid - (diff * dispHalfHeight / scaler);
            E_ASSERT(dispMid <= sweepMax);
            E_ASSERT(dispMid >= sweepMin);
            E_ASSERT(dispMin <= sweepMin);

            sweepMin = sweepMax = dataSum;
            sweepIndex = 0;
        }
        else
        {
            sweepMin = (sweepMin > dataSum) ? dataSum : sweepMin;
            sweepMax = (sweepMax < dataSum) ? dataSum : sweepMax;
            sweepIndex++;
        }

        if (0 != dispScale)
        {
            dataSum -= dispMin;
            dataSum /= dispScale;
            if (0 <= dataSum && PLOT_PIXEL_HEIGHT > dataSum)
            {
                uint8_t pageAddress = dataSum / LINE_PIXEL_HEIGHT;
                pageAddress += PLOT_LINE_FIRST;
                uint8_t pixel = 1 << (dataSum % LINE_PIXEL_HEIGHT);
                Set_Page_Address(pageAddress);
                Set_Column_Address(sweepIndex);
                oled_writeData(pixel);
            }
        }

        // Erase the data ahead of the sweep.
        int eraseIndex = sweepIndex + 10;
        eraseIndex %= PLOT_PIXEL_WIDTH;
        Set_Column_Address(eraseIndex);
        for (int i = PLOT_LINE_FIRST; i < PLOT_LINE_FIRST + PLOT_LINE_COUNT; i++)
        {
            Set_Page_Address(i);
            oled_writeData(0x00);
        }

        dataSum = 0;
    }
}

static void MAIN_DisplayInit(void)
{
    oled_init();
    //ENTIRE_DISPLAY_OFF();
    oled_putString("Microchip", 0, 0);
    oled_putString("Technology Inc.", 0, 1);
    oled_putString("RPO2 v0.1", 0, 2);
    
    __delay_ms(1500);
    oled_clear();
    
//    oled_putString("GN", 0, 1);
//    oled_putString("IR", 0, 4);
//    oled_putString("RD", 0, 7);
    
//    oled_putString("Heart", 0, 1);
//    oled_putString("SPO2", 8, 1);
//    oled_putUint8((uint8_t) 0, 0, 1);
//    oled_putUint8((uint8_t) 0, 0, 2);
    
//    oled_putString("HR(bpm)= ", 4, 0);
//    oled_putString("SPO2(%)= ", 0, 2);
}


/*******************************************************************************
 * Function Name: static bool Find_MaxMin(int24_t ir, int24_t red, int24_t green)
 * Specification: Detect the max & min value of the input pulsation signals.
 *******************************************************************************/
static bool Find_MaxMin(int24_t ir, int24_t red, int24_t green)
{
    bool max_found = 0;
    bool min_found = 0;
    bool Detection_Done = 0;
    
    int24_t data = green;
    
	switch (Find_MaxMin_State)
	{
		case 0:
			data_max = data;
			Find_MaxMin_State = 1;
			break;

		case 1:
			if (data >= data_max)
			{
				data_max = data;
				Find_MaxMin_State = 2;
			}
			else
			{
				Find_MaxMin_State = 0;
			}
			break;

		case 2:		//Finding Max
			if (data >= data_max)
			{
				data_max = data;
				Sample_Window_Counter = Sample_Window_Interval_down;		//restart counter
			}
			else
			{
				Sample_Window_Counter--;			//signal is now going down
				if (Sample_Window_Counter == 0)		//no more max peaks detected in the sampling window interval, go to detect min
				{
                    if (data_max > max_thershold)
                    {
                        max_found = 1;
                        green_pulse_max_value = data_max;
                        red_pulse_max_value = red;
                        ir_pulse_max_value = ir;
                        data_min = data;
                        Find_MaxMin_State = 3;          //go to next state - Finding Min state
                    }
				}
			}
			break;
            
        case 3:		//Finding Min
			if (data <= data_min)
			{
				data_min = data;
				Sample_Window_Counter = Sample_Window_Interval_up;		//restart counter
			}
			else
			{
				Sample_Window_Counter--;			//signal is now going up
				if (Sample_Window_Counter == 0)		//no more min peaks detected in the sampling window interval, go to detect max
				{
                    min_found = 1;
                    green_pulse_min_value = data_min;
                    red_pulse_min_value = red;
                    ir_pulse_min_value = ir;
					data_max = data;
                    Detection_Done = 1;		//Found Max & Min
					Find_MaxMin_State = 1;			//go to next state
				}
			}
			break;
            
        default:
            break;
	}
    
    return Detection_Done;
}

/*****************************************************************************
 * Function Name: SpO2_Calculation()
 * Specification: Calculate the %SpO2
 *****************************************************************************/
void SpO2_Calculation (void)
{
	IR_Vpp = fabs(ir_pulse_max_value - ir_pulse_min_value);
	Red_Vpp = fabs(red_pulse_max_value - red_pulse_min_value);

	IR_Vrms = IR_Vpp / sqrt(8);
	Red_Vrms = Red_Vpp / sqrt(8);
    
    Ratio = Red_Vrms / IR_Vrms;
/*
    if (Ratio == 0)
		NOP();
	else if (Ratio < 0.55)	//0.53
		SpO2 = 99;
	else if (Ratio < 0.60)	//0.57
		SpO2 = 98;
	else if (Ratio < 0.65)	//0.61
		SpO2 = 97;
	else if (Ratio < 0.67)	//0.63
		SpO2 = 96;
	else if (Ratio < 0.69)	//0.66
		SpO2 = 95;
	else if (Ratio < 0.70)	//0.69
		SpO2 = 94;
	else if (Ratio < 0.72)
		SpO2 = 93;
	else if (Ratio < 0.75)
		SpO2 = 92;
	else if (Ratio < 0.78)
		SpO2 = 91;
	else if (Ratio < 0.81)
		SpO2 = 90;
	else if (Ratio < 0.84)
		SpO2 = 89;
	else if (Ratio < 0.87)
		SpO2 = 88;
	else if (Ratio < 0.90)
		SpO2 = 87;
	else if (Ratio < 0.92)
		SpO2 = 86;
	else if (Ratio < 0.95)
		SpO2 = 85;
	else if (Ratio < 0.98)
		SpO2 = 84;
	else if (Ratio < 1.00)
		SpO2 = 83;
	else if (Ratio < 1.03)
		SpO2 = 82;
	else if (Ratio < 1.05)
		SpO2 = 81;
	else if (Ratio < 1.08)
		SpO2 = 80;
	else if (Ratio < 1.11)
		SpO2 = 79;
	else if (Ratio < 1.13)
		SpO2 = 78;
	else if (Ratio < 1.16)
		SpO2 = 77;
	else if (Ratio < 1.18)
		SpO2 = 76;
	else if (Ratio < 1.21)
		SpO2 = 75;
	else if (Ratio < 1.24)
		SpO2 = 74;
	else if (Ratio < 1.26)
		SpO2 = 73;
	else if (Ratio < 1.29)
		SpO2 = 72;
	else if (Ratio < 1.31)
		SpO2 = 71;
	else if (Ratio < 1.33)
		SpO2 = 70;
	else if (Ratio < 1.36)
		SpO2 = 69;
	else if (Ratio < 1.38)
		SpO2 = 68;
	else if (Ratio < 1.40)
		SpO2 = 67;
	else if (Ratio < 1.42)
		SpO2 = 66;
	else if (Ratio < 1.45)
		SpO2 = 65;
	else if (Ratio < 1.47)
		SpO2 = 64;
	else if (Ratio < 1.49)
		SpO2 = 63;
	else if (Ratio < 1.51)
		SpO2 = 62;
	else if (Ratio < 1.54)
		SpO2 = 61;
	else if (Ratio < 1.56)
		SpO2 = 60;
	else if (Ratio < 1.58)
		SpO2 = 59;
	else if (Ratio < 1.60)
		SpO2 = 58;
	else if (Ratio < 1.63)
		SpO2 = 57;
	else if (Ratio < 1.66)
		SpO2 = 56;
	else if (Ratio < 1.69)
		SpO2 = 55;
	else if (Ratio < 1.72)
		SpO2 = 54;
	else if (Ratio < 1.75)
		SpO2 = 53;
	else if (Ratio < 1.78)
		SpO2 = 52;
	else if (Ratio < 1.81)
		SpO2 = 51;
	else if (Ratio < 1.84)
		SpO2 = 50;
	else if (Ratio < 1.87)
		SpO2 = 49;
	else if (Ratio < 1.90)
		SpO2 = 48;
	else if (Ratio < 1.94)
		SpO2 = 47;
	else if (Ratio < 1.97)
		SpO2 = 46;
	else if (Ratio < 2.00)
		SpO2 = 45;
	else if (Ratio < 2.04)
		SpO2 = 44;
	else if (Ratio < 2.08)
		SpO2 = 43;
	else if (Ratio < 2.11)
		SpO2 = 42;
	else if (Ratio < 2.15)
		SpO2 = 41;
	else if (Ratio < 2.19)
		SpO2 = 40;
	else if (Ratio < 2.22)
		SpO2 = 39;
	else if (Ratio < 2.27)
		SpO2 = 38;
	else if (Ratio < 2.31)
		SpO2 = 37;
	else if (Ratio < 2.34)
		SpO2 = 36;
	else
		SpO2 = 35;
*/
    if (Ratio == 0)
		NOP();
	else if (Ratio < 0.60)	//0.53
		SpO2 = 99;
	else if (Ratio < 0.65)	//0.57
		SpO2 = 98;
	else if (Ratio < 0.70)	//0.61
		SpO2 = 97;
	else if (Ratio < 0.75)	//0.63
		SpO2 = 96;
	else if (Ratio < 1.00)	//0.66
		SpO2 = 95;
	else if (Ratio < 1.05)	//0.69
		SpO2 = 94;
	else if (Ratio < 1.10)
		SpO2 = 93;
	else if (Ratio < 1.15)
		SpO2 = 92;
	else if (Ratio < 1.20)
		SpO2 = 91;
	else if (Ratio < 1.25)
		SpO2 = 90;
	else if (Ratio < 1.30)
		SpO2 = 89;
	else if (Ratio < 1.35)
		SpO2 = 88;
	else if (Ratio < 1.40)
		SpO2 = 87;
	else if (Ratio < 1.45)
		SpO2 = 86;
	else if (Ratio < 1.50)
		SpO2 = 85;
	else if (Ratio < 1.55)
		SpO2 = 84;
	else if (Ratio < 1.60)
		SpO2 = 83;
	else if (Ratio < 1.65)
		SpO2 = 82;
	else if (Ratio < 1.70)
		SpO2 = 81;
	else if (Ratio < 1.75)
		SpO2 = 80;
/*	else if (Ratio < 1.22)
		SpO2 = 79;
	else if (Ratio < 1.23)
		SpO2 = 78;
	else if (Ratio < 1.24)
		SpO2 = 77;
	else if (Ratio < 1.25)
		SpO2 = 76;
	else if (Ratio < 1.26)
		SpO2 = 75;
	else if (Ratio < 1.27)
		SpO2 = 74;
	else if (Ratio < 1.28)
		SpO2 = 73;
	else if (Ratio < 1.29)
		SpO2 = 72;
	else if (Ratio < 1.31)
		SpO2 = 71;
	else if (Ratio < 1.33)
		SpO2 = 70;
	else if (Ratio < 1.36)
		SpO2 = 69;
	else if (Ratio < 1.38)
		SpO2 = 68;
	else if (Ratio < 1.40)
		SpO2 = 67;
	else if (Ratio < 1.42)
		SpO2 = 66;
	else if (Ratio < 1.45)
		SpO2 = 65;
	else if (Ratio < 1.47)
		SpO2 = 64;
	else if (Ratio < 1.49)
		SpO2 = 63;
	else if (Ratio < 1.51)
		SpO2 = 62;
	else if (Ratio < 1.54)
		SpO2 = 61;
	else if (Ratio < 1.56)
		SpO2 = 60;
	else if (Ratio < 1.58)
		SpO2 = 59;
	else if (Ratio < 1.60)
		SpO2 = 58;
	else if (Ratio < 1.63)
		SpO2 = 57;
	else if (Ratio < 1.66)
		SpO2 = 56;
	else if (Ratio < 1.69)
		SpO2 = 55;
	else if (Ratio < 1.72)
		SpO2 = 54;
	else if (Ratio < 1.75)
		SpO2 = 53;
	else if (Ratio < 1.78)
		SpO2 = 52;
	else if (Ratio < 1.81)
		SpO2 = 51;
	else if (Ratio < 1.84)
		SpO2 = 50;
	else if (Ratio < 1.87)
		SpO2 = 49;
	else if (Ratio < 1.90)
		SpO2 = 48;
	else if (Ratio < 1.94)
		SpO2 = 47;
	else if (Ratio < 1.97)
		SpO2 = 46;
	else if (Ratio < 2.00)
		SpO2 = 45;
	else if (Ratio < 2.04)
		SpO2 = 44;
	else if (Ratio < 2.08)
		SpO2 = 43;
	else if (Ratio < 2.11)
		SpO2 = 42;
	else if (Ratio < 2.15)
		SpO2 = 41;
	else if (Ratio < 2.19)
		SpO2 = 40;
	else if (Ratio < 2.22)
		SpO2 = 39;
	else if (Ratio < 2.27)
		SpO2 = 38;
	else if (Ratio < 2.31)
		SpO2 = 37;
	else if (Ratio < 2.34)
		SpO2 = 36;
	else
		SpO2 = 35;
*/
}


/**
 End of File
 */
